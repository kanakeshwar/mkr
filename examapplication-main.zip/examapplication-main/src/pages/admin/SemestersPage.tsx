import { useEffect, useState } from 'react';
import { Edit, Trash2, CalendarDays } from 'lucide-react';
import { supabase, type Semester, type Course } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { formatDate } from '../../lib/utils';

export function SemestersPage() {
  const { toast } = useToast();
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', semester_number: '1', course_id: '', start_date: '', end_date: '' });

  useEffect(() => { fetchSemesters(); fetchCourses(); }, []);

  const fetchSemesters = async () => {
    setLoading(true);
    const { data } = await supabase.from('semesters').select('*, course:courses(*)').order('semester_number');
    setSemesters(data || []);
    setLoading(false);
  };

  const fetchCourses = async () => {
    const { data } = await supabase.from('courses').select('*').order('name');
    setCourses(data || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ name: '', semester_number: '1', course_id: '', start_date: '', end_date: '' });
    setModalOpen(true);
  };

  const handleOpenEdit = (s: Semester) => {
    setEditId(s.id);
    setForm({
      name: s.name, semester_number: s.semester_number.toString(), course_id: s.course_id,
      start_date: s.start_date || '', end_date: s.end_date || '',
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name, semester_number: parseInt(form.semester_number), course_id: form.course_id,
        start_date: form.start_date || null, end_date: form.end_date || null,
      };
      if (editId) {
        const { error } = await supabase.from('semesters').update(payload).eq('id', editId);
        if (error) throw error;
        toast('Semester updated', 'success');
      } else {
        const { error } = await supabase.from('semesters').insert(payload);
        if (error) throw error;
        toast('Semester added', 'success');
      }
      setModalOpen(false);
      fetchSemesters();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    const { error } = await supabase.from('semesters').delete().eq('id', deleteId);
    if (error) {
      toast('Cannot delete semester with associated data', 'error');
    } else {
      toast('Semester deleted', 'success');
      fetchSemesters();
    }
    setDeleteId(null);
    setSaving(false);
  };

  const columns = [
    {
      key: 'name', header: 'Semester', sortable: true, sortValue: (s: Semester) => s.name,
      render: (s: Semester) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
            <CalendarDays className="w-5 h-5 text-warning-600 dark:text-warning-400" />
          </div>
          <span className="font-medium text-gray-900 dark:text-white">{s.name}</span>
        </div>
      ),
    },
    { key: 'number', header: 'Semester #', sortable: true, sortValue: (s: Semester) => s.semester_number, render: (s: Semester) => <Badge variant="warning">Sem {s.semester_number}</Badge> },
    { key: 'course', header: 'Course', render: (s: any) => <span className="text-sm">{s.course?.name || '-'}</span> },
    { key: 'start', header: 'Start Date', render: (s: Semester) => <span className="text-sm">{formatDate(s.start_date)}</span> },
    { key: 'end', header: 'End Date', render: (s: Semester) => <span className="text-sm">{formatDate(s.end_date)}</span> },
    {
      key: 'actions', header: 'Actions',
      render: (s: Semester) => (
        <div className="flex items-center gap-1">
          <button onClick={() => handleOpenEdit(s)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(s.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Semester Management" description="Manage academic semesters" actions={<Button onClick={handleOpenAdd}>Add Semester</Button>} />
      <DataTable columns={columns} data={semesters} loading={loading} searchKeys={['name']} searchPlaceholder="Search semesters..." exportFilename="semesters" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Semester' : 'Add Semester'} size="md">
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Semester Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required placeholder="Semester 1" />
          <Input label="Semester Number" type="number" value={form.semester_number} onChange={(e) => setForm({ ...form, semester_number: e.target.value })} min="1" max="12" required />
          <Select label="Course" value={form.course_id} onChange={(e) => setForm({ ...form, course_id: e.target.value })} required>
            <option value="">Select Course</option>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Start Date" type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} />
            <Input label="End Date" type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Semester" message="Are you sure you want to delete this semester?" confirmText="Delete" loading={saving} />
    </div>
  );
}
