import { useEffect, useState } from 'react';
import { Edit, Trash2, Plus, X, FileEdit, CheckCircle } from 'lucide-react';
import { supabase, type Question, type Subject } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { cn } from '../../lib/utils';

export function QuestionsPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    subject_id: '', question_text: '', question_type: 'mcq', difficulty: 'medium', marks: '1', explanation: '',
  });
  const [options, setOptions] = useState<string[]>(['', '', '', '']);
  const [correctOption, setCorrectOption] = useState(0);

  useEffect(() => { fetchQuestions(); fetchSubjects(); }, []);

  const fetchQuestions = async () => {
    setLoading(true);
    const { data } = await supabase.from('questions').select('*, subject:subjects(*), options(*)').order('created_at', { ascending: false });
    setQuestions(data || []);
    setLoading(false);
  };

  const fetchSubjects = async () => {
    const { data } = await supabase.from('subjects').select('*').order('name');
    setSubjects(data || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ subject_id: '', question_text: '', question_type: 'mcq', difficulty: 'medium', marks: '1', explanation: '' });
    setOptions(['', '', '', '']);
    setCorrectOption(0);
    setModalOpen(true);
  };

  const handleOpenEdit = async (q: Question) => {
    setEditId(q.id);
    setForm({
      subject_id: q.subject_id, question_text: q.question_text, question_type: q.question_type,
      difficulty: q.difficulty, marks: q.marks.toString(), explanation: q.explanation || '',
    });
    const opts = q.options || [];
    if (q.question_type === 'mcq') {
      const sorted = [...opts].sort((a, b) => a.option_order - b.option_order);
      setOptions([sorted[0]?.option_text || '', sorted[1]?.option_text || '', sorted[2]?.option_text || '', sorted[3]?.option_text || '']);
      setCorrectOption(sorted.findIndex((o) => o.is_correct));
    } else if (q.question_type === 'true_false') {
      setOptions(['True', 'False']);
      setCorrectOption(opts.find((o) => o.is_correct)?.option_text === 'True' ? 0 : 1);
    } else {
      setOptions(['', '', '', '']);
      setCorrectOption(0);
    }
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        subject_id: form.subject_id, question_text: form.question_text, question_type: form.question_type,
        difficulty: form.difficulty, marks: parseInt(form.marks), explanation: form.explanation || null,
        created_by: profile?.id,
      };
      let questionId = editId;
      if (editId) {
        const { error } = await supabase.from('questions').update(payload).eq('id', editId);
        if (error) throw error;
        await supabase.from('options').delete().eq('question_id', editId);
      } else {
        const { data, error } = await supabase.from('questions').insert(payload).select().single();
        if (error) throw error;
        questionId = data.id;
      }

      if (form.question_type === 'mcq' && questionId) {
        const optsToInsert = options.filter((o) => o.trim()).map((text, i) => ({
          question_id: questionId, option_text: text, is_correct: i === correctOption, option_order: i,
        }));
        if (optsToInsert.length > 0) {
          const { error: optError } = await supabase.from('options').insert(optsToInsert);
          if (optError) throw optError;
        }
      } else if (form.question_type === 'true_false' && questionId) {
        const { error: optError } = await supabase.from('options').insert([
          { question_id: questionId, option_text: 'True', is_correct: correctOption === 0, option_order: 0 },
          { question_id: questionId, option_text: 'False', is_correct: correctOption === 1, option_order: 1 },
        ]);
        if (optError) throw optError;
      }

      toast(editId ? 'Question updated' : 'Question added', 'success');
      setModalOpen(false);
      fetchQuestions();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    await supabase.from('questions').delete().eq('id', deleteId);
    setDeleteId(null);
    setSaving(false);
    toast('Question deleted', 'success');
    fetchQuestions();
  };

  const columns = [
    {
      key: 'question', header: 'Question', sortable: true, sortValue: (q: Question) => q.question_text,
      render: (q: Question) => (
        <div className="flex items-start gap-3 max-w-md">
          <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center flex-shrink-0">
            <FileEdit className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900 dark:text-white line-clamp-2">{q.question_text}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">{q.subject?.name}</p>
          </div>
        </div>
      ),
    },
    { key: 'type', header: 'Type', render: (q: Question) => <Badge variant="info">{q.question_type.replace('_', ' ')}</Badge> },
    { key: 'difficulty', header: 'Difficulty', sortable: true, sortValue: (q: Question) => q.difficulty, render: (q: Question) => (
      <Badge variant={q.difficulty === 'easy' ? 'success' : q.difficulty === 'medium' ? 'warning' : 'error'}>{q.difficulty}</Badge>
    ) },
    { key: 'marks', header: 'Marks', sortable: true, sortValue: (q: Question) => q.marks, render: (q: Question) => <span className="text-sm font-medium">{q.marks}</span> },
    { key: 'options', header: 'Options', render: (q: Question) => <span className="text-xs text-gray-500">{q.options?.length || 0} options</span> },
    {
      key: 'actions', header: 'Actions',
      render: (q: Question) => (
        <div className="flex items-center gap-1">
          <button onClick={() => handleOpenEdit(q)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(q.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Question Bank" description="Manage exam questions across all subjects" actions={<Button onClick={handleOpenAdd}><Plus className="w-4 h-4" /> Add Question</Button>} />
      <DataTable columns={columns} data={questions} loading={loading} searchKeys={['question_text']} searchPlaceholder="Search questions..." exportFilename="questions" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Question' : 'Add Question'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select label="Subject" value={form.subject_id} onChange={(e) => setForm({ ...form, subject_id: e.target.value })} required>
              <option value="">Select Subject</option>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Select label="Question Type" value={form.question_type} onChange={(e) => setForm({ ...form, question_type: e.target.value })}>
              <option value="mcq">Multiple Choice</option>
              <option value="true_false">True / False</option>
              <option value="descriptive">Descriptive</option>
            </Select>
            <Select label="Difficulty" value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })}>
              <option value="easy">Easy</option>
              <option value="medium">Medium</option>
              <option value="hard">Hard</option>
            </Select>
            <Input label="Marks" type="number" value={form.marks} onChange={(e) => setForm({ ...form, marks: e.target.value })} min="1" required />
          </div>
          <Textarea label="Question Text" value={form.question_text} onChange={(e) => setForm({ ...form, question_text: e.target.value })} rows={3} required />

          {form.question_type === 'mcq' && (
            <div>
              <label className="label">Options (select the correct answer)</label>
              <div className="space-y-2">
                {options.map((opt, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setCorrectOption(i)}
                      className={cn(
                        'w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0',
                        correctOption === i ? 'border-success-500 bg-success-500' : 'border-gray-300 dark:border-gray-600'
                      )}
                    >
                      {correctOption === i && <CheckCircle className="w-4 h-4 text-white" />}
                    </button>
                    <input
                      type="text"
                      value={opt}
                      onChange={(e) => {
                        const newOpts = [...options];
                        newOpts[i] = e.target.value;
                        setOptions(newOpts);
                      }}
                      placeholder={`Option ${i + 1}`}
                      className="input"
                      required={i < 2}
                    />
                    {options.length > 2 && (
                      <button type="button" onClick={() => setOptions(options.filter((_, idx) => idx !== i))} className="p-1.5 text-gray-400 hover:text-error-500">
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                {options.length < 6 && (
                  <button type="button" onClick={() => setOptions([...options, ''])} className="text-sm text-primary-600 dark:text-primary-400 hover:underline">
                    + Add Option
                  </button>
                )}
              </div>
            </div>
          )}

          {form.question_type === 'true_false' && (
            <div>
              <label className="label">Correct Answer</label>
              <div className="flex gap-3">
                {['True', 'False'].map((opt, i) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setCorrectOption(i)}
                    className={cn(
                      'flex-1 p-3 rounded-lg border-2 text-sm font-medium transition-all',
                      correctOption === i ? 'border-success-500 bg-success-50 dark:bg-success-900/20 text-success-700 dark:text-success-300' : 'border-gray-200 dark:border-gray-700'
                    )}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          )}

          <Textarea label="Explanation (optional)" value={form.explanation} onChange={(e) => setForm({ ...form, explanation: e.target.value })} rows={2} />
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Question" message="Are you sure you want to delete this question?" confirmText="Delete" loading={saving} />
    </div>
  );
}
