import { useEffect, useState } from 'react';
import { Edit, Trash2, BookOpen, Calendar } from 'lucide-react';
import { supabase, type Course, type Department } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

export function CoursesPage() {
  const { toast } = useToast();
  const [courses, setCourses] = useState<Course[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', code: '', description: '', department_id: '', duration_years: '4', total_semesters: '8' });

  useEffect(() => { fetchCourses(); fetchDepartments(); }, []);

  const fetchCourses = async () => {
    setLoading(true);
    const { data } = await supabase.from('courses').select('*, department:departments(*)').order('name');
    setCourses(data || []);
    setLoading(false);
  };

  const fetchDepartments = async () => {
    const { data } = await supabase.from('departments').select('*').order('name');
    setDepartments(data || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ name: '', code: '', description: '', department_id: '', duration_years: '4', total_semesters: '8' });
    setModalOpen(true);
  };

  const handleOpenEdit = (c: Course) => {
    setEditId(c.id);
    setForm({ name: c.name, code: c.code, description: c.description || '', department_id: c.department_id || '', duration_years: c.duration_years.toString(), total_semesters: c.total_semesters.toString() });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name, code: form.code, description: form.description || null,
        department_id: form.department_id || null,
        duration_years: parseInt(form.duration_years), total_semesters: parseInt(form.total_semesters),
      };
      if (editId) {
        const { error } = await supabase.from('courses').update(payload).eq('id', editId);
        if (error) throw error;
        toast('Course updated', 'success');
      } else {
        const { error } = await supabase.from('courses').insert(payload);
        if (error) throw error;
        toast('Course added', 'success');
      }
      setModalOpen(false);
      fetchCourses();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    const { error } = await supabase.from('courses').delete().eq('id', deleteId);
    if (error) {
      toast('Cannot delete course with associated data', 'error');
    } else {
      toast('Course deleted', 'success');
      fetchCourses();
    }
    setDeleteId(null);
    setSaving(false);
  };

  const columns = [
    {
      key: 'name', header: 'Course', sortable: true, sortValue: (c: Course) => c.name,
      render: (c: Course) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-accent-100 dark:bg-accent-900/30 flex items-center justify-center">
            <BookOpen className="w-5 h-5 text-accent-600 dark:text-accent-400" />
          </div>
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{c.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{c.description}</p>
          </div>
        </div>
      ),
    },
    { key: 'code', header: 'Code', sortable: true, sortValue: (c: Course) => c.code, render: (c: Course) => <Badge variant="primary">{c.code}</Badge> },
    { key: 'department', header: 'Department', render: (c: Course) => <span className="text-sm">{c.department?.name || '-'}</span> },
    { key: 'duration', header: 'Duration', sortable: true, sortValue: (c: Course) => c.duration_years, render: (c: Course) => <span className="text-sm">{c.duration_years} years</span> },
    { key: 'semesters', header: 'Semesters', render: (c: Course) => <Badge variant="info"><Calendar className="w-3 h-3 mr-1" /> {c.total_semesters}</Badge> },
    {
      key: 'actions', header: 'Actions',
      render: (c: Course) => (
        <div className="flex items-center gap-1">
          <button onClick={() => handleOpenEdit(c)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(c.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Course Management" description="Manage degree programs and courses" actions={<Button onClick={handleOpenAdd}>Add Course</Button>} />
      <DataTable columns={columns} data={courses} loading={loading} searchKeys={['name', 'code']} searchPlaceholder="Search courses..." exportFilename="courses" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Course' : 'Add Course'} size="md">
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Course Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <Input label="Course Code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required placeholder="BTECH-CSE" />
          <Textarea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          <Select label="Department" value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
            <option value="">Select Department</option>
            {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Duration (Years)" type="number" value={form.duration_years} onChange={(e) => setForm({ ...form, duration_years: e.target.value })} min="1" max="6" required />
            <Input label="Total Semesters" type="number" value={form.total_semesters} onChange={(e) => setForm({ ...form, total_semesters: e.target.value })} min="1" max="12" required />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Course" message="Are you sure you want to delete this course?" confirmText="Delete" loading={saving} />
    </div>
  );
}
