import { useEffect, useState } from 'react';
import { Download, Eye, TrendingUp, Users, CheckCircle, XCircle } from 'lucide-react';
import { supabase, type Mark, type Exam } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { StatCard } from '../../components/ui/StatCard';
import { BarChart, DonutChart } from '../../components/charts/Charts';
import { useToast } from '../../components/ui/Toast';
import { calculateGrade, exportToCSV } from '../../lib/utils';

export function ResultsPage() {
  const { toast } = useToast();
  const [marks, setMarks] = useState<Mark[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedExam, setSelectedExam] = useState('');
  const [viewModal, setViewModal] = useState<Mark | null>(null);
  const [stats, setStats] = useState({ total: 0, passed: 0, failed: 0, avgPercentage: 0 });

  useEffect(() => { fetchExams(); fetchMarks(); }, []);

  const fetchExams = async () => {
    const { data } = await supabase.from('exams').select('*').order('created_at', { ascending: false });
    setExams(data || []);
  };

  const fetchMarks = async () => {
    setLoading(true);
    let query = supabase.from('marks').select('*, student:students(*, profile:profiles(*)), subject:subjects(*), exam:exams(*), semester:semesters(*)').order('created_at', { ascending: false });
    if (selectedExam) query = query.eq('exam_id', selectedExam);
    const { data } = await query;
    const marksData = data || [];
    setMarks(marksData);

    const total = marksData.length;
    const passed = marksData.filter((m) => (m.marks_obtained / m.total_marks) * 100 >= 40).length;
    const failed = total - passed;
    const avgPercentage = total > 0 ? Math.round(marksData.reduce((sum, m) => sum + (m.marks_obtained / m.total_marks) * 100, 0) / total) : 0;
    setStats({ total, passed, failed, avgPercentage });
    setLoading(false);
  };

  useEffect(() => { fetchMarks(); }, [selectedExam]);

  const handlePublish = async (mark: Mark) => {
    await supabase.from('marks').update({ is_published: !mark.is_published }).eq('id', mark.id);
    toast(mark.is_published ? 'Result unpublished' : 'Result published', 'success');
    fetchMarks();
  };

  const handleExport = () => {
    const headers = ['Student', 'Roll No', 'Subject', 'Exam', 'Marks Obtained', 'Total Marks', 'Percentage', 'Grade', 'Status'];
    const rows = marks.map((m) => [
      m.student?.profile?.full_name || '',
      m.student?.roll_number || '',
      m.subject?.name || '',
      m.exam?.title || '',
      m.marks_obtained,
      m.total_marks,
      ((m.marks_obtained / m.total_marks) * 100).toFixed(2),
      m.grade || calculateGrade((m.marks_obtained / m.total_marks) * 100),
      m.is_published ? 'Published' : 'Draft',
    ]);
    exportToCSV('results.csv', headers, rows);
    toast('Results exported', 'success');
  };

  const gradeDistribution = [
    { label: 'A+ (90+)', value: marks.filter((m) => (m.marks_obtained / m.total_marks) * 100 >= 90).length, color: '#22c55e' },
    { label: 'A (80-89)', value: marks.filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 80 && p < 90; }).length, color: '#3b82f6' },
    { label: 'B (60-79)', value: marks.filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 60 && p < 80; }).length, color: '#f59e0b' },
    { label: 'C (40-59)', value: marks.filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 40 && p < 60; }).length, color: '#06b6d4' },
    { label: 'F (<40)', value: marks.filter((m) => (m.marks_obtained / m.total_marks) * 100 < 40).length, color: '#ef4444' },
  ];

  const subjectPerformance = marks.reduce((acc, m) => {
    const subject = m.subject?.name || 'Unknown';
    if (!acc[subject]) acc[subject] = { total: 0, count: 0 };
    acc[subject].total += (m.marks_obtained / m.total_marks) * 100;
    acc[subject].count += 1;
    return acc;
  }, {} as Record<string, { total: number; count: number }>);

  const subjectChart = Object.entries(subjectPerformance).map(([label, v]) => ({
    label: label.split(' ')[0],
    value: Math.round(v.total / v.count),
  }));

  const columns = [
    {
      key: 'student', header: 'Student', sortable: true, sortValue: (m: Mark) => m.student?.profile?.full_name || '',
      render: (m: Mark) => (
        <div className="flex items-center gap-3">
          <Avatar name={m.student?.profile?.full_name || '?'} size="sm" />
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{m.student?.profile?.full_name}</p>
            <p className="text-xs text-gray-500">{m.student?.roll_number}</p>
          </div>
        </div>
      ),
    },
    { key: 'subject', header: 'Subject', render: (m: Mark) => <span className="text-sm">{m.subject?.name}</span> },
    { key: 'exam', header: 'Exam', render: (m: Mark) => <span className="text-sm">{m.exam?.title || '-'}</span> },
    {
      key: 'marks', header: 'Marks', sortable: true, sortValue: (m: Mark) => m.marks_obtained,
      render: (m: Mark) => <span className="font-medium text-sm">{m.marks_obtained}/{m.total_marks}</span>,
    },
    {
      key: 'percentage', header: 'Percentage', sortable: true, sortValue: (m: Mark) => (m.marks_obtained / m.total_marks) * 100,
      render: (m: Mark) => {
        const pct = (m.marks_obtained / m.total_marks) * 100;
        return <Badge variant={pct >= 40 ? 'success' : 'error'}>{pct.toFixed(1)}%</Badge>;
      },
    },
    { key: 'grade', header: 'Grade', render: (m: Mark) => <Badge variant="primary">{m.grade || calculateGrade((m.marks_obtained / m.total_marks) * 100)}</Badge> },
    {
      key: 'status', header: 'Status',
      render: (m: Mark) => (
        <button onClick={() => handlePublish(m)}>
          <Badge variant={m.is_published ? 'success' : 'default'}>{m.is_published ? 'Published' : 'Draft'}</Badge>
        </button>
      ),
    },
    {
      key: 'actions', header: 'Actions',
      render: (m: Mark) => (
        <button onClick={() => setViewModal(m)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500">
          <Eye className="w-4 h-4" />
        </button>
      ),
    },
  ];

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader
        title="Result Management"
        description="View, publish, and export examination results"
        actions={
          <div className="flex items-center gap-2">
            <Select value={selectedExam} onChange={(e) => setSelectedExam(e.target.value)} className="w-48">
              <option value="">All Exams</option>
              {exams.map((e) => <option key={e.id} value={e.id}>{e.title}</option>)}
            </Select>
            <Button onClick={handleExport} variant="outline"><Download className="w-4 h-4" /> Export</Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Results" value={stats.total} icon={<Users className="w-6 h-6" />} color="primary" />
        <StatCard title="Passed" value={stats.passed} icon={<CheckCircle className="w-6 h-6" />} color="success" />
        <StatCard title="Failed" value={stats.failed} icon={<XCircle className="w-6 h-6" />} color="error" />
        <StatCard title="Avg Percentage" value={`${stats.avgPercentage}%`} icon={<TrendingUp className="w-6 h-6" />} color="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Grade Distribution</CardTitle></CardHeader>
          <CardContent>
            {gradeDistribution.some((g) => g.value > 0) ? (
              <DonutChart data={gradeDistribution} centerLabel="Results" centerValue={stats.total} />
            ) : (
              <div className="py-12 text-center text-gray-500">No data available</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Subject Performance</CardTitle></CardHeader>
          <CardContent>
            {subjectChart.length > 0 ? (
              <BarChart data={subjectChart} height={240} />
            ) : (
              <div className="py-12 text-center text-gray-500">No data available</div>
            )}
          </CardContent>
        </Card>
      </div>

      <DataTable columns={columns} data={marks} loading={loading} searchKeys={[]} searchPlaceholder="Search results..." exportFilename="results" emptyMessage="No results found" />

      <Modal open={!!viewModal} onClose={() => setViewModal(null)} title="Result Details" size="md">
        {viewModal && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Avatar name={viewModal.student?.profile?.full_name || '?'} size="xl" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{viewModal.student?.profile?.full_name}</h3>
                <p className="text-sm text-gray-500">{viewModal.student?.roll_number}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-xs text-gray-500">Subject</p><p className="text-sm font-medium">{viewModal.subject?.name}</p></div>
              <div><p className="text-xs text-gray-500">Exam</p><p className="text-sm font-medium">{viewModal.exam?.title || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Marks Obtained</p><p className="text-sm font-medium">{viewModal.marks_obtained}/{viewModal.total_marks}</p></div>
              <div><p className="text-xs text-gray-500">Percentage</p><p className="text-sm font-medium">{((viewModal.marks_obtained / viewModal.total_marks) * 100).toFixed(2)}%</p></div>
              <div><p className="text-xs text-gray-500">Grade</p><Badge variant="primary">{viewModal.grade || calculateGrade((viewModal.marks_obtained / viewModal.total_marks) * 100)}</Badge></div>
              <div><p className="text-xs text-gray-500">Status</p><Badge variant={viewModal.is_published ? 'success' : 'default'}>{viewModal.is_published ? 'Published' : 'Draft'}</Badge></div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
