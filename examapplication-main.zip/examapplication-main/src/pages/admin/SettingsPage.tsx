import { useState } from 'react';
import { Settings, Shield, Database, Bell, GraduationCap, Save } from 'lucide-react';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { useToast } from '../../components/ui/Toast';

export function SettingsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('academic');
  const [saving, setSaving] = useState(false);
  const [academicYear, setAcademicYear] = useState('2025-2026');
  const [gradingSystem, setGradingSystem] = useState('absolute');

  const tabs = [
    { id: 'academic', label: 'Academic Year', icon: GraduationCap },
    { id: 'grading', label: 'Grading System', icon: Settings },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'backup', label: 'Backup', icon: Database },
    { id: 'notifications', label: 'Notifications', icon: Bell },
  ];

  const handleSave = () => {
    setSaving(true);
    setTimeout(() => {
      setSaving(false);
      toast('Settings saved successfully', 'success');
    }, 800);
  };

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Settings" description="Configure system-wide settings" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1">
          <CardContent className="p-3">
            <div className="space-y-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                      activeTab === tab.id
                        ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                        : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-3">
          <CardHeader><CardTitle>{tabs.find((t) => t.id === activeTab)?.label}</CardTitle></CardHeader>
          <CardContent>
            {activeTab === 'academic' && (
              <div className="space-y-4">
                <Input label="Academic Year" value={academicYear} onChange={(e) => setAcademicYear(e.target.value)} placeholder="2025-2026" />
                <Select label="Current Semester">
                  <option value="1">Semester 1 (Odd)</option>
                  <option value="2">Semester 2 (Even)</option>
                </Select>
                <div className="grid grid-cols-2 gap-4">
                  <Input label="Session Start Date" type="date" />
                  <Input label="Session End Date" type="date" />
                </div>
              </div>
            )}
            {activeTab === 'grading' && (
              <div className="space-y-4">
                <Select label="Grading System" value={gradingSystem} onChange={(e) => setGradingSystem(e.target.value)}>
                  <option value="absolute">Absolute Grading</option>
                  <option value="relative">Relative Grading</option>
                </Select>
                <div className="space-y-2">
                  <p className="text-sm font-medium text-gray-700 dark:text-gray-300">Grade Scale</p>
                  {[
                    { grade: 'A+', range: '90-100', point: '10' },
                    { grade: 'A', range: '80-89', point: '9' },
                    { grade: 'B+', range: '70-79', point: '8' },
                    { grade: 'B', range: '60-69', point: '7' },
                    { grade: 'C', range: '50-59', point: '6' },
                    { grade: 'D', range: '40-49', point: '5' },
                    { grade: 'F', range: '<40', point: '0' },
                  ].map((g) => (
                    <div key={g.grade} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
                      <Badge variant="primary">{g.grade}</Badge>
                      <span className="text-sm text-gray-600 dark:text-gray-400">{g.range}%</span>
                      <span className="text-sm font-medium">Grade Point: {g.point}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            {activeTab === 'security' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Two-Factor Authentication</p>
                    <p className="text-xs text-gray-500">Add an extra layer of security</p>
                  </div>
                  <Badge variant="error">Disabled</Badge>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Password Policy</p>
                    <p className="text-xs text-gray-500">Minimum 8 characters, mixed case</p>
                  </div>
                  <Badge variant="success">Enabled</Badge>
                </div>
                <div className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Session Timeout</p>
                    <p className="text-xs text-gray-500">Auto logout after 30 minutes of inactivity</p>
                  </div>
                  <Badge variant="success">Enabled</Badge>
                </div>
              </div>
            )}
            {activeTab === 'backup' && (
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Database Backup</p>
                  <p className="text-xs text-gray-500 mt-1">Last backup: Never</p>
                  <Button size="sm" className="mt-3"><Database className="w-4 h-4" /> Create Backup Now</Button>
                </div>
                <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">Auto Backup</p>
                  <p className="text-xs text-gray-500 mt-1">Schedule automatic daily backups</p>
                  <Select className="mt-3" defaultValue="daily">
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </Select>
                </div>
              </div>
            )}
            {activeTab === 'notifications' && (
              <div className="space-y-4">
                {['Email Notifications', 'Exam Reminders', 'Result Notifications', 'System Alerts'].map((item) => (
                  <div key={item} className="flex items-center justify-between p-4 rounded-lg border border-gray-200 dark:border-gray-700">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{item}</p>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" defaultChecked className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                    </label>
                  </div>
                ))}
              </div>
            )}
            <div className="flex justify-end pt-4">
              <Button onClick={handleSave} loading={saving}><Save className="w-4 h-4" /> Save Changes</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
