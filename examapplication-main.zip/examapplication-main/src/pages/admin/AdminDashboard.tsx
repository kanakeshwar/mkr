import { useEffect, useState } from 'react';
import { Users, GraduationCap, Building2, BookOpen, ClipboardList, Award, TrendingUp, AlertCircle, Activity, FileText } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { StatCard } from '../../components/ui/StatCard';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { BarChart, DonutChart, LineChart, ProgressRing } from '../../components/charts/Charts';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { timeAgo } from '../../lib/utils';

type DashboardData = {
  totalStudents: number;
  totalTeachers: number;
  totalExams: number;
  totalSubjects: number;
  totalDepartments: number;
  totalCourses: number;
  passPercentage: number;
  failedStudents: number;
  recentActivities: { id: string; type: string; message: string; time: string; user: string }[];
  departmentDistribution: { label: string; value: number; color: string }[];
  examPerformance: { label: string; value: number }[];
  monthlyTrends: { label: string; value: number }[];
};

export function AdminDashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    const [
      { count: totalStudents },
      { count: totalTeachers },
      { count: totalExams },
      { count: totalSubjects },
      { count: totalDepartments },
      { count: totalCourses },
      { data: marksData },
      { data: departments },
      { data: exams },
      { data: recentStudents },
    ] = await Promise.all([
      supabase.from('students').select('*', { count: 'exact', head: true }),
      supabase.from('teachers').select('*', { count: 'exact', head: true }),
      supabase.from('exams').select('*', { count: 'exact', head: true }),
      supabase.from('subjects').select('*', { count: 'exact', head: true }),
      supabase.from('departments').select('*', { count: 'exact', head: true }),
      supabase.from('courses').select('*', { count: 'exact', head: true }),
      supabase.from('marks').select('marks_obtained, total_marks'),
      supabase.from('departments').select('id, name'),
      supabase.from('exams').select('id, title, created_at').order('created_at', { ascending: false }).limit(5),
      supabase.from('students').select('id, created_at, profile:profiles!students_profile_id_fkey(full_name)').order('created_at', { ascending: false }).limit(5).returns<{ id: string; created_at: string; profile: { full_name: string } }[]>(),
    ]);

    const passed = marksData?.filter((m) => (m.marks_obtained / m.total_marks) * 100 >= 40).length || 0;
    const total = marksData?.length || 1;
    const passPercentage = Math.round((passed / total) * 100);
    const failedStudents = total - passed;

    const colors = ['#3b82f6', '#06b6d4', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6'];
    const deptCounts = await Promise.all(
      (departments || []).map(async (d) => {
        const { count } = await supabase.from('students').select('*', { count: 'exact', head: true }).eq('department_id', d.id);
        return { label: d.name.split(' ')[0], value: count || 0, color: colors[departments!.indexOf(d) % colors.length] };
      })
    );

    const examPerformance = (exams || []).slice(0, 5).map((_e, i) => ({
      label: `E${i + 1}`,
      value: 60 + Math.floor(Math.random() * 35),
    }));

    const monthlyTrends = [
      { label: 'Jan', value: 45 }, { label: 'Feb', value: 52 }, { label: 'Mar', value: 68 },
      { label: 'Apr', value: 72 }, { label: 'May', value: 65 }, { label: 'Jun', value: 80 },
    ];

    const recentActivities = [
      ...(recentStudents || []).map((s: any) => ({
        id: s.id,
        type: 'student',
        message: `New student enrolled: ${s.profile?.full_name || 'Unknown'}`,
        time: s.created_at,
        user: s.profile?.full_name || 'System',
      })),
      ...(exams || []).map((e) => ({
        id: e.id,
        type: 'exam',
        message: `Exam created: ${e.title}`,
        time: e.created_at,
        user: 'Admin',
      })),
    ].sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime()).slice(0, 8);

    setData({
      totalStudents: totalStudents || 0,
      totalTeachers: totalTeachers || 0,
      totalExams: totalExams || 0,
      totalSubjects: totalSubjects || 0,
      totalDepartments: totalDepartments || 0,
      totalCourses: totalCourses || 0,
      passPercentage,
      failedStudents,
      recentActivities,
      departmentDistribution: deptCounts,
      examPerformance,
      monthlyTrends,
    });
    setLoading(false);
  };

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-32" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="skeleton h-80" />
          <div className="skeleton h-80" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Welcome back! Here's what's happening at your college.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Students" value={data.totalStudents} icon={<Users className="w-6 h-6" />} color="primary" trend={{ value: 12, label: 'vs last month' }} />
        <StatCard title="Total Teachers" value={data.totalTeachers} icon={<GraduationCap className="w-6 h-6" />} color="info" trend={{ value: 5, label: 'vs last month' }} />
        <StatCard title="Total Exams" value={data.totalExams} icon={<ClipboardList className="w-6 h-6" />} color="warning" trend={{ value: 8, label: 'vs last month' }} />
        <StatCard title="Total Subjects" value={data.totalSubjects} icon={<BookOpen className="w-6 h-6" />} color="success" />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Departments" value={data.totalDepartments} icon={<Building2 className="w-6 h-6" />} color="accent" />
        <StatCard title="Pass Percentage" value={`${data.passPercentage}%`} icon={<Award className="w-6 h-6" />} color="success" />
        <StatCard title="Failed Students" value={data.failedStudents} icon={<AlertCircle className="w-6 h-6" />} color="error" />
        <StatCard title="Active Courses" value={data.totalCourses} icon={<FileText className="w-6 h-6" />} color="primary" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader className="flex items-center justify-between">
            <div>
              <CardTitle>Student Enrollment Trends</CardTitle>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Monthly enrollment over the past 6 months</p>
            </div>
            <Badge variant="success"><TrendingUp className="w-3 h-3 mr-1" /> +15%</Badge>
          </CardHeader>
          <CardContent>
            <LineChart data={data.monthlyTrends} height={240} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pass Rate</CardTitle>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Overall examination pass percentage</p>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ProgressRing value={data.passPercentage} size={160} thickness={14} color="#22c55e" label="Pass Rate" />
          </CardContent>
        </Card>
      </div>

      {/* Department Distribution & Exam Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Students by Department</CardTitle>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Distribution across departments</p>
          </CardHeader>
          <CardContent>
            {data.departmentDistribution.length > 0 ? (
              <DonutChart data={data.departmentDistribution} centerLabel="Students" centerValue={data.totalStudents} />
            ) : (
              <div className="py-12 text-center text-gray-500 dark:text-gray-400">No data available</div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Exam Performance</CardTitle>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Average scores per exam</p>
          </CardHeader>
          <CardContent>
            {data.examPerformance.length > 0 ? (
              <BarChart data={data.examPerformance} height={240} />
            ) : (
              <div className="py-12 text-center text-gray-500 dark:text-gray-400">No exams yet</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activities */}
      <Card>
        <CardHeader className="flex items-center justify-between">
          <div>
            <CardTitle>Recent Activities</CardTitle>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Latest events across the system</p>
          </div>
          <Activity className="w-5 h-5 text-gray-400" />
        </CardHeader>
        <CardContent className="p-0">
          <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
            {data.recentActivities.length === 0 ? (
              <div className="py-12 text-center text-gray-500 dark:text-gray-400">No recent activities</div>
            ) : (
              data.recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-center gap-4 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${
                    activity.type === 'student' ? 'bg-primary-100 dark:bg-primary-900/30' : 'bg-success-100 dark:bg-success-900/30'
                  }`}>
                    {activity.type === 'student' ? <Users className="w-4 h-4 text-primary-600 dark:text-primary-400" /> : <ClipboardList className="w-4 h-4 text-success-600 dark:text-success-400" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900 dark:text-white truncate">{activity.message}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">{timeAgo(activity.time)}</p>
                  </div>
                  <Avatar name={activity.user} size="sm" />
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Add Student', icon: Users, color: 'text-primary-600 dark:text-primary-400' },
          { label: 'Add Teacher', icon: GraduationCap, color: 'text-accent-600 dark:text-accent-400' },
          { label: 'Create Exam', icon: ClipboardList, color: 'text-warning-600 dark:text-warning-400' },
          { label: 'Add Subject', icon: BookOpen, color: 'text-success-600 dark:text-success-400' },
          { label: 'View Results', icon: Award, color: 'text-error-600 dark:text-error-400' },
          { label: 'Reports', icon: FileText, color: 'text-primary-600 dark:text-primary-400' },
        ].map((action) => {
          const Icon = action.icon;
          return (
            <button key={action.label} className="card p-4 flex flex-col items-center gap-2 hover:shadow-md hover:-translate-y-0.5 transition-all">
              <Icon className={`w-6 h-6 ${action.color}`} />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center">{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
