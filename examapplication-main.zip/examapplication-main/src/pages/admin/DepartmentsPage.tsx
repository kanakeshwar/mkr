import { useEffect, useState } from 'react';
import { Edit, Trash2, Building2, Users } from 'lucide-react';
import { supabase, type Department } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Textarea } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

export function DepartmentsPage() {
  const { toast } = useToast();
  const [departments, setDepartments] = useState<(Department & { student_count?: number })[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', code: '', description: '', head_of_department: '', established_year: '' });

  useEffect(() => { fetchDepartments(); }, []);

  const fetchDepartments = async () => {
    setLoading(true);
    const { data } = await supabase.from('departments').select('*').order('name');
    const deptsWithCounts = await Promise.all(
      (data || []).map(async (d) => {
        const { count } = await supabase.from('students').select('*', { count: 'exact', head: true }).eq('department_id', d.id);
        return { ...d, student_count: count || 0 };
      })
    );
    setDepartments(deptsWithCounts);
    setLoading(false);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ name: '', code: '', description: '', head_of_department: '', established_year: '' });
    setModalOpen(true);
  };

  const handleOpenEdit = (d: Department) => {
    setEditId(d.id);
    setForm({ name: d.name, code: d.code, description: d.description || '', head_of_department: d.head_of_department || '', established_year: d.established_year?.toString() || '' });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editId) {
        const { error } = await supabase.from('departments').update({
          name: form.name, code: form.code, description: form.description || null,
          head_of_department: form.head_of_department || null,
          established_year: form.established_year ? parseInt(form.established_year) : null,
        }).eq('id', editId);
        if (error) throw error;
        toast('Department updated', 'success');
      } else {
        const { error } = await supabase.from('departments').insert({
          name: form.name, code: form.code, description: form.description || null,
          head_of_department: form.head_of_department || null,
          established_year: form.established_year ? parseInt(form.established_year) : null,
        });
        if (error) throw error;
        toast('Department added', 'success');
      }
      setModalOpen(false);
      fetchDepartments();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    const { error } = await supabase.from('departments').delete().eq('id', deleteId);
    if (error) {
      toast('Cannot delete department with assigned students/teachers', 'error');
    } else {
      toast('Department deleted', 'success');
      fetchDepartments();
    }
    setDeleteId(null);
    setSaving(false);
  };

  const columns = [
    {
      key: 'name', header: 'Department', sortable: true, sortValue: (d: Department) => d.name,
      render: (d: Department) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
            <Building2 className="w-5 h-5 text-primary-600 dark:text-primary-400" />
          </div>
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{d.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{d.description}</p>
          </div>
        </div>
      ),
    },
    { key: 'code', header: 'Code', sortable: true, sortValue: (d: Department) => d.code, render: (d: Department) => <Badge variant="primary">{d.code}</Badge> },
    { key: 'head', header: 'Head of Dept', render: (d: Department) => <span className="text-sm">{d.head_of_department || '-'}</span> },
    { key: 'established', header: 'Established', sortable: true, sortValue: (d: Department) => d.established_year || 0, render: (d: Department) => <span className="text-sm">{d.established_year || '-'}</span> },
    { key: 'students', header: 'Students', render: (d: Department & { student_count?: number }) => (
      <Badge variant="info"><Users className="w-3 h-3 mr-1" /> {d.student_count || 0}</Badge>
    ) },
    {
      key: 'actions', header: 'Actions',
      render: (d: Department) => (
        <div className="flex items-center gap-1">
          <button onClick={() => handleOpenEdit(d)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(d.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Department Management" description="Manage academic departments" actions={<Button onClick={handleOpenAdd}>Add Department</Button>} />
      <DataTable columns={columns} data={departments} loading={loading} searchKeys={['name', 'code']} searchPlaceholder="Search departments..." exportFilename="departments" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Department' : 'Add Department'} size="md">
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Department Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <Input label="Department Code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required placeholder="CSE, ECE, ME" />
          <Textarea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          <div className="grid grid-cols-2 gap-4">
            <Input label="Head of Department" value={form.head_of_department} onChange={(e) => setForm({ ...form, head_of_department: e.target.value })} />
            <Input label="Established Year" type="number" value={form.established_year} onChange={(e) => setForm({ ...form, established_year: e.target.value })} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Department" message="Are you sure you want to delete this department?" confirmText="Delete" loading={saving} />
    </div>
  );
}
