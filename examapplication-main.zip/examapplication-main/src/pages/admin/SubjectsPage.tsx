import { useEffect, useState } from 'react';
import { Edit, Trash2, FileText } from 'lucide-react';
import { supabase, type Subject, type Course, type Semester } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';

export function SubjectsPage() {
  const { toast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', code: '', description: '', course_id: '', semester_id: '', credits: '4', total_marks: '100', passing_marks: '40' });

  useEffect(() => { fetchSubjects(); fetchReferenceData(); }, []);

  const fetchSubjects = async () => {
    setLoading(true);
    const { data } = await supabase.from('subjects').select('*, course:courses(*), semester:semesters(*)').order('name');
    setSubjects(data || []);
    setLoading(false);
  };

  const fetchReferenceData = async () => {
    const [{ data: c }, { data: s }] = await Promise.all([
      supabase.from('courses').select('*').order('name'),
      supabase.from('semesters').select('*').order('semester_number'),
    ]);
    setCourses(c || []);
    setSemesters(s || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ name: '', code: '', description: '', course_id: '', semester_id: '', credits: '4', total_marks: '100', passing_marks: '40' });
    setModalOpen(true);
  };

  const handleOpenEdit = (s: Subject) => {
    setEditId(s.id);
    setForm({
      name: s.name, code: s.code, description: s.description || '',
      course_id: s.course_id || '', semester_id: s.semester_id || '',
      credits: s.credits.toString(), total_marks: s.total_marks.toString(), passing_marks: s.passing_marks.toString(),
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        name: form.name, code: form.code, description: form.description || null,
        course_id: form.course_id || null, semester_id: form.semester_id || null,
        credits: parseInt(form.credits), total_marks: parseInt(form.total_marks), passing_marks: parseInt(form.passing_marks),
      };
      if (editId) {
        const { error } = await supabase.from('subjects').update(payload).eq('id', editId);
        if (error) throw error;
        toast('Subject updated', 'success');
      } else {
        const { error } = await supabase.from('subjects').insert(payload);
        if (error) throw error;
        toast('Subject added', 'success');
      }
      setModalOpen(false);
      fetchSubjects();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    const { error } = await supabase.from('subjects').delete().eq('id', deleteId);
    if (error) {
      toast('Cannot delete subject with associated data', 'error');
    } else {
      toast('Subject deleted', 'success');
      fetchSubjects();
    }
    setDeleteId(null);
    setSaving(false);
  };

  const columns = [
    {
      key: 'name', header: 'Subject', sortable: true, sortValue: (s: Subject) => s.name,
      render: (s: Subject) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-success-100 dark:bg-success-900/30 flex items-center justify-center">
            <FileText className="w-5 h-5 text-success-600 dark:text-success-400" />
          </div>
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{s.name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{s.description}</p>
          </div>
        </div>
      ),
    },
    { key: 'code', header: 'Code', sortable: true, sortValue: (s: Subject) => s.code, render: (s: Subject) => <Badge variant="primary">{s.code}</Badge> },
    { key: 'course', header: 'Course', render: (s: Subject) => <span className="text-sm">{s.course?.name || '-'}</span> },
    { key: 'semester', header: 'Semester', render: (s: Subject) => <Badge variant="info">Sem {s.semester?.semester_number || '-'}</Badge> },
    { key: 'credits', header: 'Credits', sortable: true, sortValue: (s: Subject) => s.credits, render: (s: Subject) => <span className="text-sm font-medium">{s.credits}</span> },
    { key: 'marks', header: 'Passing', render: (s: Subject) => <span className="text-sm">{s.passing_marks}/{s.total_marks}</span> },
    {
      key: 'actions', header: 'Actions',
      render: (s: Subject) => (
        <div className="flex items-center gap-1">
          <button onClick={() => handleOpenEdit(s)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(s.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Subject Management" description="Manage academic subjects" actions={<Button onClick={handleOpenAdd}>Add Subject</Button>} />
      <DataTable columns={columns} data={subjects} loading={loading} searchKeys={['name', 'code']} searchPlaceholder="Search subjects..." exportFilename="subjects" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Subject' : 'Add Subject'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Subject Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            <Input label="Subject Code" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} required placeholder="CS101" />
            <Select label="Course" value={form.course_id} onChange={(e) => setForm({ ...form, course_id: e.target.value })}>
              <option value="">Select Course</option>
              {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            <Select label="Semester" value={form.semester_id} onChange={(e) => setForm({ ...form, semester_id: e.target.value })}>
              <option value="">Select Semester</option>
              {semesters.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Input label="Credits" type="number" value={form.credits} onChange={(e) => setForm({ ...form, credits: e.target.value })} min="1" max="10" required />
            <Input label="Total Marks" type="number" value={form.total_marks} onChange={(e) => setForm({ ...form, total_marks: e.target.value })} min="1" required />
            <Input label="Passing Marks" type="number" value={form.passing_marks} onChange={(e) => setForm({ ...form, passing_marks: e.target.value })} min="1" required />
          </div>
          <Textarea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add'}</Button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Subject" message="Are you sure you want to delete this subject?" confirmText="Delete" loading={saving} />
    </div>
  );
}
