import { useEffect, useState } from 'react';
import { Users, Award, CheckSquare, TrendingUp, Download, GraduationCap, BookOpen } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Input';
import { StatCard } from '../../components/ui/StatCard';
import { BarChart, LineChart, DonutChart, PieChart } from '../../components/charts/Charts';
import { useToast } from '../../components/ui/Toast';
import { exportToCSV } from '../../lib/utils';

export function ReportsPage() {
  const { toast } = useToast();
  const [reportType, setReportType] = useState('overview');
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>({});

  useEffect(() => { fetchReportData(); }, []);

  const fetchReportData = async () => {
    setLoading(true);
    const [
      { count: totalStudents },
      { count: totalTeachers },
      { count: totalExams },
      { count: totalSubjects },
      { data: marksData },
      { data: attendanceData },
      { data: departments },
    ] = await Promise.all([
      supabase.from('students').select('*', { count: 'exact', head: true }),
      supabase.from('teachers').select('*', { count: 'exact', head: true }),
      supabase.from('exams').select('*', { count: 'exact', head: true }),
      supabase.from('subjects').select('*', { count: 'exact', head: true }),
      supabase.from('marks').select('marks_obtained, total_marks, student:students!marks_student_id_fkey(department_id, department:departments(name))').returns<any[]>(),
      supabase.from('attendance').select('status, student:students!attendance_student_id_fkey(department:departments(name))'),
      supabase.from('departments').select('id, name'),
    ]);

    const deptPerformance = (departments || []).map((d, i) => {
      const deptMarks = (marksData || []).filter((m) => m.student?.department_id === d.id);
      const avg = deptMarks.length > 0 ? Math.round(deptMarks.reduce((s, m) => s + (m.marks_obtained / m.total_marks) * 100, 0) / deptMarks.length) : 0;
      return { label: d.name.split(' ')[0], value: avg, color: ['#3b82f6', '#06b6d4', '#22c55e', '#f59e0b', '#ef4444'][i % 5] };
    }).filter((d) => d.value > 0);

    const attendanceStats = {
      present: (attendanceData || []).filter((a) => a.status === 'present').length,
      absent: (attendanceData || []).filter((a) => a.status === 'absent').length,
      late: (attendanceData || []).filter((a) => a.status === 'late').length,
    };

    const monthlyPerformance = [
      { label: 'Jan', value: 65 }, { label: 'Feb', value: 72 }, { label: 'Mar', value: 78 },
      { label: 'Apr', value: 82 }, { label: 'May', value: 75 }, { label: 'Jun', value: 88 },
    ];

    const gradeDistribution = [
      { label: 'A+', value: (marksData || []).filter((m) => (m.marks_obtained / m.total_marks) * 100 >= 90).length, color: '#22c55e' },
      { label: 'A', value: (marksData || []).filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 80 && p < 90; }).length, color: '#3b82f6' },
      { label: 'B', value: (marksData || []).filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 60 && p < 80; }).length, color: '#f59e0b' },
      { label: 'C', value: (marksData || []).filter((m) => { const p = (m.marks_obtained / m.total_marks) * 100; return p >= 40 && p < 60; }).length, color: '#06b6d4' },
      { label: 'F', value: (marksData || []).filter((m) => (m.marks_obtained / m.total_marks) * 100 < 40).length, color: '#ef4444' },
    ];

    setData({
      totalStudents: totalStudents || 0,
      totalTeachers: totalTeachers || 0,
      totalExams: totalExams || 0,
      totalSubjects: totalSubjects || 0,
      deptPerformance,
      attendanceStats,
      monthlyPerformance,
      gradeDistribution,
    });
    setLoading(false);
  };

  const handleExport = () => {
    const headers = ['Metric', 'Value'];
    const rows = [
      ['Total Students', data.totalStudents],
      ['Total Teachers', data.totalTeachers],
      ['Total Exams', data.totalExams],
      ['Total Subjects', data.totalSubjects],
      ['Present Count', data.attendanceStats?.present || 0],
      ['Absent Count', data.attendanceStats?.absent || 0],
      ['Late Count', data.attendanceStats?.late || 0],
    ];
    exportToCSV('report.csv', headers, rows);
    toast('Report exported', 'success');
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-32" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="skeleton h-80" />
          <div className="skeleton h-80" />
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader
        title="Reports & Analytics"
        description="Comprehensive reports across all modules"
        actions={
          <div className="flex items-center gap-2">
            <Select value={reportType} onChange={(e) => setReportType(e.target.value)} className="w-48">
              <option value="overview">Overview Report</option>
              <option value="attendance">Attendance Report</option>
              <option value="marks">Marks Report</option>
              <option value="performance">Performance Report</option>
            </Select>
            <Button onClick={handleExport} variant="outline"><Download className="w-4 h-4" /> Export</Button>
          </div>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Students" value={data.totalStudents} icon={<Users className="w-6 h-6" />} color="primary" />
        <StatCard title="Total Teachers" value={data.totalTeachers} icon={<GraduationCap className="w-6 h-6" />} color="info" />
        <StatCard title="Total Exams" value={data.totalExams} icon={<Award className="w-6 h-6" />} color="warning" />
        <StatCard title="Total Subjects" value={data.totalSubjects} icon={<BookOpen className="w-6 h-6" />} color="success" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Department Performance</CardTitle></CardHeader>
          <CardContent>
            {data.deptPerformance?.length > 0 ? (
              <BarChart data={data.deptPerformance} height={240} />
            ) : (
              <div className="py-12 text-center text-gray-500">No data available</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Grade Distribution</CardTitle></CardHeader>
          <CardContent>
            {data.gradeDistribution?.some((g: any) => g.value > 0) ? (
              <PieChart data={data.gradeDistribution} />
            ) : (
              <div className="py-12 text-center text-gray-500">No data available</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle>Monthly Performance Trend</CardTitle></CardHeader>
          <CardContent>
            <LineChart data={data.monthlyPerformance || []} height={240} color="#06b6d4" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Attendance Overview</CardTitle></CardHeader>
          <CardContent>
            {data.attendanceStats && (data.attendanceStats.present + data.attendanceStats.absent + data.attendanceStats.late) > 0 ? (
              <DonutChart
                data={[
                  { label: 'Present', value: data.attendanceStats.present, color: '#22c55e' },
                  { label: 'Absent', value: data.attendanceStats.absent, color: '#ef4444' },
                  { label: 'Late', value: data.attendanceStats.late, color: '#f59e0b' },
                ]}
                centerLabel="Total"
                centerValue={data.attendanceStats.present + data.attendanceStats.absent + data.attendanceStats.late}
              />
            ) : (
              <div className="py-12 text-center text-gray-500">No attendance data</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Report Types</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: 'Student Report', desc: 'Individual student performance', icon: Users, color: 'text-primary-600' },
              { title: 'Attendance Report', desc: 'Attendance statistics', icon: CheckSquare, color: 'text-success-600' },
              { title: 'Marks Report', desc: 'Subject-wise marks analysis', icon: Award, color: 'text-warning-600' },
              { title: 'Performance Report', desc: 'Overall performance metrics', icon: TrendingUp, color: 'text-accent-600' },
            ].map((r) => {
              const Icon = r.icon;
              return (
                <div key={r.title} className="p-4 rounded-lg border border-gray-200 dark:border-gray-700 hover:shadow-md transition-all cursor-pointer">
                  <Icon className={`w-8 h-8 ${r.color} mb-3`} />
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">{r.title}</h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{r.desc}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
