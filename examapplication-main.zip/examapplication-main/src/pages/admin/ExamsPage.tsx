import { useEffect, useState } from 'react';
import { Edit, Trash2, Eye, ClipboardList, Clock, Plus, Settings2 } from 'lucide-react';
import { supabase, type Exam, type Subject, type Course, type Semester, type Question } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { formatDateTime, cn } from '../../lib/utils';

export function ExamsPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [exams, setExams] = useState<Exam[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [viewModal, setViewModal] = useState<Exam | null>(null);
  const [questionsModal, setQuestionsModal] = useState<Exam | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [selectedQuestions, setSelectedQuestions] = useState<string[]>([]);
  const [form, setForm] = useState({
    title: '', description: '', subject_id: '', course_id: '', semester_id: '',
    exam_type: 'mcq_test', total_marks: '100', passing_marks: '40', duration_minutes: '180',
    start_time: '', end_time: '', negative_marking: '0', randomize_questions: false,
    auto_submit: false, auto_evaluate: true, is_published: false,
  });

  useEffect(() => { fetchExams(); fetchReferenceData(); }, []);

  const fetchExams = async () => {
    setLoading(true);
    const { data } = await supabase.from('exams').select('*, subject:subjects(*), course:courses(*), semester:semesters(*)').order('created_at', { ascending: false });
    setExams(data || []);
    setLoading(false);
  };

  const fetchReferenceData = async () => {
    const [{ data: sub }, { data: c }, { data: s }] = await Promise.all([
      supabase.from('subjects').select('*').order('name'),
      supabase.from('courses').select('*').order('name'),
      supabase.from('semesters').select('*').order('semester_number'),
    ]);
    setSubjects(sub || []);
    setCourses(c || []);
    setSemesters(s || []);
  };

  const fetchQuestions = async (subjectId: string) => {
    const { data } = await supabase.from('questions').select('*, options(*)').eq('subject_id', subjectId).order('created_at');
    setQuestions(data || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({
      title: '', description: '', subject_id: '', course_id: '', semester_id: '',
      exam_type: 'mcq_test', total_marks: '100', passing_marks: '40', duration_minutes: '180',
      start_time: '', end_time: '', negative_marking: '0', randomize_questions: false,
      auto_submit: false, auto_evaluate: true, is_published: false,
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (e: Exam) => {
    setEditId(e.id);
    setForm({
      title: e.title, description: e.description || '', subject_id: e.subject_id, course_id: e.course_id || '',
      semester_id: e.semester_id || '', exam_type: e.exam_type, total_marks: e.total_marks.toString(),
      passing_marks: e.passing_marks.toString(), duration_minutes: e.duration_minutes.toString(),
      start_time: e.start_time ? new Date(e.start_time).toISOString().slice(0, 16) : '',
      end_time: e.end_time ? new Date(e.end_time).toISOString().slice(0, 16) : '',
      negative_marking: e.negative_marking.toString(), randomize_questions: e.randomize_questions,
      auto_submit: e.auto_submit, auto_evaluate: e.auto_evaluate, is_published: e.is_published,
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const payload = {
        title: form.title, description: form.description || null, subject_id: form.subject_id,
        course_id: form.course_id || null, semester_id: form.semester_id || null,
        exam_type: form.exam_type, total_marks: parseInt(form.total_marks), passing_marks: parseInt(form.passing_marks),
        duration_minutes: parseInt(form.duration_minutes),
        start_time: form.start_time ? new Date(form.start_time).toISOString() : null,
        end_time: form.end_time ? new Date(form.end_time).toISOString() : null,
        negative_marking: parseFloat(form.negative_marking) || 0,
        randomize_questions: form.randomize_questions, auto_submit: form.auto_submit,
        auto_evaluate: form.auto_evaluate, is_published: form.is_published,
        created_by: profile?.id,
      };
      if (editId) {
        const { error } = await supabase.from('exams').update(payload).eq('id', editId);
        if (error) throw error;
        toast('Exam updated', 'success');
      } else {
        const { error } = await supabase.from('exams').insert(payload);
        if (error) throw error;
        toast('Exam created', 'success');
      }
      setModalOpen(false);
      fetchExams();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    await supabase.from('exams').delete().eq('id', deleteId);
    setDeleteId(null);
    setSaving(false);
    toast('Exam deleted', 'success');
    fetchExams();
  };

  const togglePublish = async (exam: Exam) => {
    await supabase.from('exams').update({ is_published: !exam.is_published }).eq('id', exam.id);
    toast(exam.is_published ? 'Exam unpublished' : 'Exam published', 'success');
    fetchExams();
  };

  const openQuestionsModal = async (exam: Exam) => {
    setQuestionsModal(exam);
    if (exam.subject_id) {
      await fetchQuestions(exam.subject_id);
      const { data: eq } = await supabase.from('exam_questions').select('question_id').eq('exam_id', exam.id);
      setSelectedQuestions(eq?.map((e) => e.question_id) || []);
    }
  };

  const toggleQuestion = async (questionId: string) => {
    if (!questionsModal) return;
    if (selectedQuestions.includes(questionId)) {
      await supabase.from('exam_questions').delete().eq('exam_id', questionsModal.id).eq('question_id', questionId);
      setSelectedQuestions(selectedQuestions.filter((id) => id !== questionId));
    } else {
      const question = questions.find((q) => q.id === questionId);
      await supabase.from('exam_questions').insert({
        exam_id: questionsModal.id, question_id: questionId,
        marks: question?.marks || 1, question_order: selectedQuestions.length,
      });
      setSelectedQuestions([...selectedQuestions, questionId]);
    }
  };

  const columns = [
    {
      key: 'title', header: 'Exam', sortable: true, sortValue: (e: Exam) => e.title,
      render: (e: Exam) => (
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
            <ClipboardList className="w-5 h-5 text-warning-600 dark:text-warning-400" />
          </div>
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{e.title}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{e.subject?.name}</p>
          </div>
        </div>
      ),
    },
    { key: 'type', header: 'Type', render: (e: Exam) => <Badge variant="info">{e.exam_type.replace('_', ' ').toUpperCase()}</Badge> },
    { key: 'duration', header: 'Duration', render: (e: Exam) => <span className="text-sm flex items-center gap-1"><Clock className="w-3 h-3" /> {e.duration_minutes}m</span> },
    { key: 'marks', header: 'Marks', render: (e: Exam) => <span className="text-sm">{e.total_marks}</span> },
    { key: 'schedule', header: 'Schedule', render: (e: Exam) => <span className="text-xs text-gray-500">{formatDateTime(e.start_time)}</span> },
    {
      key: 'status', header: 'Status',
      render: (e: Exam) => (
        <button onClick={(ev) => { ev.stopPropagation(); togglePublish(e); }}>
          <Badge variant={e.is_published ? 'success' : 'default'}>{e.is_published ? 'Published' : 'Draft'}</Badge>
        </button>
      ),
    },
    {
      key: 'actions', header: 'Actions',
      render: (e: Exam) => (
        <div className="flex items-center gap-1">
          <button onClick={() => openQuestionsModal(e)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-accent-600 dark:text-accent-400" title="Manage Questions"><Settings2 className="w-4 h-4" /></button>
          <button onClick={() => setViewModal(e)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"><Eye className="w-4 h-4" /></button>
          <button onClick={() => handleOpenEdit(e)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(e.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Exam Management" description="Create and manage examinations" actions={<Button onClick={handleOpenAdd}><Plus className="w-4 h-4" /> Create Exam</Button>} />
      <DataTable columns={columns} data={exams} loading={loading} searchKeys={['title']} searchPlaceholder="Search exams..." exportFilename="exams" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Exam' : 'Create New Exam'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Exam Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <Textarea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} />
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Select label="Subject" value={form.subject_id} onChange={(e) => setForm({ ...form, subject_id: e.target.value })} required>
              <option value="">Select Subject</option>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Select label="Exam Type" value={form.exam_type} onChange={(e) => setForm({ ...form, exam_type: e.target.value })}>
              <option value="mcq_test">MCQ Test</option>
              <option value="descriptive">Descriptive</option>
              <option value="mixed">Mixed</option>
            </Select>
            <Select label="Course" value={form.course_id} onChange={(e) => setForm({ ...form, course_id: e.target.value })}>
              <option value="">Select Course</option>
              {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            <Select label="Semester" value={form.semester_id} onChange={(e) => setForm({ ...form, semester_id: e.target.value })}>
              <option value="">Select Semester</option>
              {semesters.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Input label="Total Marks" type="number" value={form.total_marks} onChange={(e) => setForm({ ...form, total_marks: e.target.value })} required />
            <Input label="Passing Marks" type="number" value={form.passing_marks} onChange={(e) => setForm({ ...form, passing_marks: e.target.value })} required />
            <Input label="Duration (minutes)" type="number" value={form.duration_minutes} onChange={(e) => setForm({ ...form, duration_minutes: e.target.value })} required />
            <Input label="Negative Marking" type="number" step="0.25" value={form.negative_marking} onChange={(e) => setForm({ ...form, negative_marking: e.target.value })} />
            <Input label="Start Time" type="datetime-local" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
            <Input label="End Time" type="datetime-local" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { key: 'randomize_questions', label: 'Randomize' },
              { key: 'auto_submit', label: 'Auto Submit' },
              { key: 'auto_evaluate', label: 'Auto Evaluate' },
              { key: 'is_published', label: 'Publish' },
            ].map((opt) => (
              <label key={opt.key} className="flex items-center gap-2 cursor-pointer p-2.5 rounded-lg border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800">
                <input
                  type="checkbox"
                  checked={form[opt.key as keyof typeof form] as boolean}
                  onChange={(e) => setForm({ ...form, [opt.key]: e.target.checked })}
                  className="w-4 h-4 rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-sm text-gray-700 dark:text-gray-300">{opt.label}</span>
              </label>
            ))}
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Create'}</Button>
          </div>
        </form>
      </Modal>

      <Modal open={!!viewModal} onClose={() => setViewModal(null)} title="Exam Details" size="md">
        {viewModal && (
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{viewModal.title}</h3>
              <p className="text-sm text-gray-500 dark:text-gray-400">{viewModal.description}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-xs text-gray-500">Subject</p><p className="text-sm font-medium">{viewModal.subject?.name}</p></div>
              <div><p className="text-xs text-gray-500">Type</p><Badge variant="info">{viewModal.exam_type.replace('_', ' ')}</Badge></div>
              <div><p className="text-xs text-gray-500">Total Marks</p><p className="text-sm font-medium">{viewModal.total_marks}</p></div>
              <div><p className="text-xs text-gray-500">Passing Marks</p><p className="text-sm font-medium">{viewModal.passing_marks}</p></div>
              <div><p className="text-xs text-gray-500">Duration</p><p className="text-sm font-medium">{viewModal.duration_minutes} minutes</p></div>
              <div><p className="text-xs text-gray-500">Negative Marking</p><p className="text-sm font-medium">{viewModal.negative_marking}</p></div>
              <div><p className="text-xs text-gray-500">Start Time</p><p className="text-sm font-medium">{formatDateTime(viewModal.start_time)}</p></div>
              <div><p className="text-xs text-gray-500">End Time</p><p className="text-sm font-medium">{formatDateTime(viewModal.end_time)}</p></div>
            </div>
            <div className="flex gap-2 flex-wrap pt-2">
              {viewModal.randomize_questions && <Badge variant="primary">Randomized</Badge>}
              {viewModal.auto_submit && <Badge variant="warning">Auto Submit</Badge>}
              {viewModal.auto_evaluate && <Badge variant="success">Auto Evaluate</Badge>}
              <Badge variant={viewModal.is_published ? 'success' : 'default'}>{viewModal.is_published ? 'Published' : 'Draft'}</Badge>
            </div>
          </div>
        )}
      </Modal>

      <Modal open={!!questionsModal} onClose={() => setQuestionsModal(null)} title={`Questions: ${questionsModal?.title || ''}`} size="lg">
        <div className="space-y-3">
          <p className="text-sm text-gray-500 dark:text-gray-400">Select questions to include in this exam. {selectedQuestions.length} selected.</p>
          {questions.length === 0 ? (
            <div className="py-8 text-center text-gray-500 dark:text-gray-400">
              No questions found for this subject. Add questions to the Question Bank first.
            </div>
          ) : (
            questions.map((q, i) => (
              <div
                key={q.id}
                onClick={() => toggleQuestion(q.id)}
                className={cn(
                  'p-4 rounded-lg border-2 cursor-pointer transition-all',
                  selectedQuestions.includes(q.id)
                    ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                )}
              >
                <div className="flex items-start gap-3">
                  <div className={cn(
                    'w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5',
                    selectedQuestions.includes(q.id) ? 'border-primary-500 bg-primary-500' : 'border-gray-300 dark:border-gray-600'
                  )}>
                    {selectedQuestions.includes(q.id) && <span className="text-white text-xs">✓</span>}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{i + 1}. {q.question_text}</p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <Badge variant={q.difficulty === 'easy' ? 'success' : q.difficulty === 'medium' ? 'warning' : 'error'}>{q.difficulty}</Badge>
                      <Badge variant="default">{q.question_type}</Badge>
                      <span className="text-xs text-gray-500">{q.marks} marks</span>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Exam" message="Are you sure you want to delete this exam?" confirmText="Delete" loading={saving} />
    </div>
  );
}
