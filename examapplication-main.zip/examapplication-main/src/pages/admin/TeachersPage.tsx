import { useEffect, useState } from 'react';
import { Edit, Trash2, Eye, Mail } from 'lucide-react';
import { supabase, type Teacher, type Department } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { formatDate } from '../../lib/utils';

export function TeachersPage() {
  const { toast } = useToast();
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [viewModal, setViewModal] = useState<Teacher | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    full_name: '', email: '', employee_id: '', department_id: '',
    designation: 'Assistant Professor', qualification: '', specialization: '',
  });

  useEffect(() => { fetchTeachers(); fetchDepartments(); }, []);

  const fetchTeachers = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('teachers')
      .select('*, profile:profiles(*), department:departments(*)')
      .order('created_at', { ascending: false });
    setTeachers(data || []);
    setLoading(false);
  };

  const fetchDepartments = async () => {
    const { data } = await supabase.from('departments').select('*').order('name');
    setDepartments(data || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({ full_name: '', email: '', employee_id: '', department_id: '', designation: 'Assistant Professor', qualification: '', specialization: '' });
    setModalOpen(true);
  };

  const handleOpenEdit = (t: Teacher) => {
    setEditId(t.id);
    setForm({
      full_name: t.profile?.full_name || '', email: t.profile?.email || '', employee_id: t.employee_id,
      department_id: t.department_id || '', designation: t.designation, qualification: t.qualification || '',
      specialization: t.specialization || '',
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (editId) {
        const existing = teachers.find((t) => t.id === editId);
        if (existing?.profile_id) {
          await supabase.from('profiles').update({ full_name: form.full_name, email: form.email }).eq('id', existing.profile_id);
        }
        await supabase.from('teachers').update({
          employee_id: form.employee_id, department_id: form.department_id || null,
          designation: form.designation, qualification: form.qualification || null,
          specialization: form.specialization || null,
        }).eq('id', editId);
        toast('Teacher updated successfully', 'success');
      } else {
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: form.email, password: 'password123',
          options: { data: { full_name: form.full_name, role: 'teacher' } },
        });
        if (authError) throw authError;
        if (authData.user) {
          await supabase.from('teachers').insert({
            profile_id: authData.user.id, employee_id: form.employee_id,
            department_id: form.department_id || null, designation: form.designation,
            qualification: form.qualification || null, specialization: form.specialization || null,
          });
        }
        toast('Teacher added successfully', 'success');
      }
      setModalOpen(false);
      fetchTeachers();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save teacher', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    await supabase.from('teachers').delete().eq('id', deleteId);
    setDeleteId(null);
    setSaving(false);
    toast('Teacher deleted', 'success');
    fetchTeachers();
  };

  const columns = [
    {
      key: 'name', header: 'Teacher', sortable: true, sortValue: (t: Teacher) => t.profile?.full_name || '',
      render: (t: Teacher) => (
        <div className="flex items-center gap-3">
          <Avatar name={t.profile?.full_name || '?'} src={t.profile?.avatar_url} size="sm" />
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{t.profile?.full_name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{t.profile?.email}</p>
          </div>
        </div>
      ),
    },
    { key: 'employee_id', header: 'Employee ID', sortable: true, sortValue: (t: Teacher) => t.employee_id, render: (t: Teacher) => <span className="font-mono text-sm">{t.employee_id}</span> },
    { key: 'department', header: 'Department', render: (t: Teacher) => <span className="text-sm">{t.department?.name || '-'}</span> },
    { key: 'designation', header: 'Designation', sortable: true, sortValue: (t: Teacher) => t.designation, render: (t: Teacher) => <Badge variant="info">{t.designation}</Badge> },
    {
      key: 'actions', header: 'Actions',
      render: (t: Teacher) => (
        <div className="flex items-center gap-1">
          <button onClick={() => setViewModal(t)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"><Eye className="w-4 h-4" /></button>
          <button onClick={() => handleOpenEdit(t)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400"><Edit className="w-4 h-4" /></button>
          <button onClick={() => setDeleteId(t.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400"><Trash2 className="w-4 h-4" /></button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Teacher Management" description="Manage faculty members and their department assignments" actions={<Button onClick={handleOpenAdd}>Add Teacher</Button>} />
      <DataTable columns={columns} data={teachers} loading={loading} searchKeys={['employee_id']} searchPlaceholder="Search by employee ID..." exportFilename="teachers" />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Teacher' : 'Add New Teacher'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Full Name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
            <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required disabled={!!editId} />
            <Input label="Employee ID" value={form.employee_id} onChange={(e) => setForm({ ...form, employee_id: e.target.value })} required />
            <Select label="Department" value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
              <option value="">Select Department</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
            <Select label="Designation" value={form.designation} onChange={(e) => setForm({ ...form, designation: e.target.value })}>
              <option value="Professor">Professor</option>
              <option value="Associate Professor">Associate Professor</option>
              <option value="Assistant Professor">Assistant Professor</option>
              <option value="Lecturer">Lecturer</option>
              <option value="Visiting Faculty">Visiting Faculty</option>
            </Select>
            <Input label="Qualification" value={form.qualification} onChange={(e) => setForm({ ...form, qualification: e.target.value })} placeholder="Ph.D., M.Tech" />
            <Input label="Specialization" value={form.specialization} onChange={(e) => setForm({ ...form, specialization: e.target.value })} placeholder="Data Structures, AI" />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add Teacher'}</Button>
          </div>
        </form>
      </Modal>

      <Modal open={!!viewModal} onClose={() => setViewModal(null)} title="Teacher Details" size="md">
        {viewModal && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Avatar name={viewModal.profile?.full_name || '?'} src={viewModal.profile?.avatar_url} size="xl" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{viewModal.profile?.full_name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 flex items-center gap-1"><Mail className="w-3 h-3" /> {viewModal.profile?.email}</p>
                <Badge variant="info" className="mt-1">{viewModal.designation}</Badge>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div><p className="text-xs text-gray-500">Employee ID</p><p className="text-sm font-medium">{viewModal.employee_id}</p></div>
              <div><p className="text-xs text-gray-500">Department</p><p className="text-sm font-medium">{viewModal.department?.name || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Qualification</p><p className="text-sm font-medium">{viewModal.qualification || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Specialization</p><p className="text-sm font-medium">{viewModal.specialization || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Joining Date</p><p className="text-sm font-medium">{formatDate(viewModal.joining_date)}</p></div>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog open={!!deleteId} onClose={() => setDeleteId(null)} onConfirm={handleDelete} title="Delete Teacher" message="Are you sure you want to delete this teacher?" confirmText="Delete" loading={saving} />
    </div>
  );
}
