import { useEffect, useState } from 'react';
import { Edit, Trash2, Eye } from 'lucide-react';
import { supabase, type Student, type Department, type Course, type Semester } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { useToast } from '../../components/ui/Toast';
import { formatDate } from '../../lib/utils';

export function StudentsPage() {
  const { toast } = useToast();
  const [students, setStudents] = useState<Student[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [semesters, setSemesters] = useState<Semester[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [viewModal, setViewModal] = useState<Student | null>(null);
  const [editId, setEditId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    full_name: '',
    email: '',
    roll_number: '',
    enrollment_number: '',
    department_id: '',
    course_id: '',
    semester_id: '',
    current_semester: '1',
    guardian_name: '',
    guardian_phone: '',
    blood_group: '',
    address: '',
  });

  useEffect(() => {
    fetchStudents();
    fetchReferenceData();
  }, []);

  const fetchStudents = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('students')
      .select('*, profile:profiles(*), department:departments(*), course:courses(*), semester:semesters(*)')
      .order('created_at', { ascending: false });
    setStudents(data || []);
    setLoading(false);
  };

  const fetchReferenceData = async () => {
    const [{ data: depts }, { data: crses }, { data: sems }] = await Promise.all([
      supabase.from('departments').select('*').order('name'),
      supabase.from('courses').select('*').order('name'),
      supabase.from('semesters').select('*').order('semester_number'),
    ]);
    setDepartments(depts || []);
    setCourses(crses || []);
    setSemesters(sems || []);
  };

  const handleOpenAdd = () => {
    setEditId(null);
    setForm({
      full_name: '', email: '', roll_number: '', enrollment_number: '',
      department_id: '', course_id: '', semester_id: '', current_semester: '1',
      guardian_name: '', guardian_phone: '', blood_group: '', address: '',
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (student: Student) => {
    setEditId(student.id);
    setForm({
      full_name: student.profile?.full_name || '',
      email: student.profile?.email || '',
      roll_number: student.roll_number,
      enrollment_number: student.enrollment_number || '',
      department_id: student.department_id || '',
      course_id: student.course_id || '',
      semester_id: student.semester_id || '',
      current_semester: String(student.current_semester),
      guardian_name: student.guardian_name || '',
      guardian_phone: student.guardian_phone || '',
      blood_group: student.blood_group || '',
      address: student.address || '',
    });
    setModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      if (editId) {
        const existing = students.find((s) => s.id === editId);
        if (existing?.profile_id) {
          await supabase.from('profiles').update({
            full_name: form.full_name,
            email: form.email,
          }).eq('id', existing.profile_id);
        }
        const { error } = await supabase.from('students').update({
          roll_number: form.roll_number,
          enrollment_number: form.enrollment_number || null,
          department_id: form.department_id || null,
          course_id: form.course_id || null,
          semester_id: form.semester_id || null,
          current_semester: parseInt(form.current_semester),
          guardian_name: form.guardian_name || null,
          guardian_phone: form.guardian_phone || null,
          blood_group: form.blood_group || null,
          address: form.address || null,
        }).eq('id', editId);
        if (error) throw error;
        toast('Student updated successfully', 'success');
      } else {
        const tempPassword = 'password123';
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: form.email,
          password: tempPassword,
          options: { data: { full_name: form.full_name, role: 'student' } },
        });
        if (authError) throw authError;
        if (authData.user) {
          const { error: studentError } = await supabase.from('students').insert({
            profile_id: authData.user.id,
            roll_number: form.roll_number,
            enrollment_number: form.enrollment_number || null,
            department_id: form.department_id || null,
            course_id: form.course_id || null,
            semester_id: form.semester_id || null,
            current_semester: parseInt(form.current_semester),
            guardian_name: form.guardian_name || null,
            guardian_phone: form.guardian_phone || null,
            blood_group: form.blood_group || null,
            address: form.address || null,
          });
          if (studentError) throw studentError;
        }
        toast('Student added successfully', 'success');
      }
      setModalOpen(false);
      fetchStudents();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save student', 'error');
    }
    setSaving(false);
  };

  const handleDelete = async () => {
    if (!deleteId) return;
    setSaving(true);
    const student = students.find((s) => s.id === deleteId);
    if (student?.profile_id) {
      await supabase.from('students').delete().eq('id', deleteId);
    }
    setDeleteId(null);
    setSaving(false);
    toast('Student deleted', 'success');
    fetchStudents();
  };

  const columns = [
    {
      key: 'name',
      header: 'Student',
      sortable: true,
      sortValue: (s: Student) => s.profile?.full_name || '',
      render: (s: Student) => (
        <div className="flex items-center gap-3">
          <Avatar name={s.profile?.full_name || '?'} src={s.profile?.avatar_url} size="sm" />
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{s.profile?.full_name}</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">{s.profile?.email}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'roll_number',
      header: 'Roll No',
      sortable: true,
      sortValue: (s: Student) => s.roll_number,
      render: (s: Student) => <span className="font-mono text-sm">{s.roll_number}</span>,
    },
    {
      key: 'department',
      header: 'Department',
      render: (s: Student) => <span className="text-sm">{s.department?.name || '-'}</span>,
    },
    {
      key: 'course',
      header: 'Course',
      render: (s: Student) => <span className="text-sm">{s.course?.name || '-'}</span>,
    },
    {
      key: 'semester',
      header: 'Semester',
      sortable: true,
      sortValue: (s: Student) => s.current_semester,
      render: (s: Student) => <Badge variant="info">Sem {s.current_semester}</Badge>,
    },
    {
      key: 'status',
      header: 'Status',
      render: (s: Student) => (
        <Badge variant={s.is_active ? 'success' : 'error'}>
          {s.is_active ? 'Active' : 'Inactive'}
        </Badge>
      ),
    },
    {
      key: 'actions',
      header: 'Actions',
      render: (s: Student) => (
        <div className="flex items-center gap-1">
          <button onClick={() => setViewModal(s)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500 dark:text-gray-400" title="View">
            <Eye className="w-4 h-4" />
          </button>
          <button onClick={() => handleOpenEdit(s)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-primary-600 dark:text-primary-400" title="Edit">
            <Edit className="w-4 h-4" />
          </button>
          <button onClick={() => setDeleteId(s.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-600 dark:text-error-400" title="Delete">
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader
        title="Student Management"
        description="Manage student records, enrollment, and department assignments"
        actions={<Button onClick={handleOpenAdd}>Add Student</Button>}
      />

      <DataTable
        columns={columns}
        data={students}
        loading={loading}
        onRowClick={(s) => setViewModal(s)}
        searchKeys={['roll_number', 'enrollment_number']}
        searchPlaceholder="Search by roll number..."
        exportFilename="students"
        emptyMessage="No students found. Add your first student!"
      />

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editId ? 'Edit Student' : 'Add New Student'} size="lg">
        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Full Name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
            <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required disabled={!!editId} />
            <Input label="Roll Number" value={form.roll_number} onChange={(e) => setForm({ ...form, roll_number: e.target.value })} required />
            <Input label="Enrollment Number" value={form.enrollment_number} onChange={(e) => setForm({ ...form, enrollment_number: e.target.value })} />
            <Select label="Department" value={form.department_id} onChange={(e) => setForm({ ...form, department_id: e.target.value })}>
              <option value="">Select Department</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </Select>
            <Select label="Course" value={form.course_id} onChange={(e) => setForm({ ...form, course_id: e.target.value })}>
              <option value="">Select Course</option>
              {courses.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </Select>
            <Select label="Semester" value={form.semester_id} onChange={(e) => setForm({ ...form, semester_id: e.target.value })}>
              <option value="">Select Semester</option>
              {semesters.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Input label="Current Semester" type="number" value={form.current_semester} onChange={(e) => setForm({ ...form, current_semester: e.target.value })} min="1" max="12" required />
            <Input label="Guardian Name" value={form.guardian_name} onChange={(e) => setForm({ ...form, guardian_name: e.target.value })} />
            <Input label="Guardian Phone" value={form.guardian_phone} onChange={(e) => setForm({ ...form, guardian_phone: e.target.value })} />
            <Select label="Blood Group" value={form.blood_group} onChange={(e) => setForm({ ...form, blood_group: e.target.value })}>
              <option value="">Select</option>
              <option value="A+">A+</option>
              <option value="A-">A-</option>
              <option value="B+">B+</option>
              <option value="B-">B-</option>
              <option value="AB+">AB+</option>
              <option value="AB-">AB-</option>
              <option value="O+">O+</option>
              <option value="O-">O-</option>
            </Select>
            <Input label="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>{editId ? 'Update' : 'Add Student'}</Button>
          </div>
        </form>
      </Modal>

      <Modal open={!!viewModal} onClose={() => setViewModal(null)} title="Student Details" size="md">
        {viewModal && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Avatar name={viewModal.profile?.full_name || '?'} src={viewModal.profile?.avatar_url} size="xl" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{viewModal.profile?.full_name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{viewModal.profile?.email}</p>
                <Badge variant={viewModal.is_active ? 'success' : 'error'} className="mt-1">
                  {viewModal.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Roll Number</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.roll_number}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Enrollment No</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.enrollment_number || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Department</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.department?.name || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Course</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.course?.name || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Semester</p><p className="text-sm font-medium text-gray-900 dark:text-white">Semester {viewModal.current_semester}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Admission Date</p><p className="text-sm font-medium text-gray-900 dark:text-white">{formatDate(viewModal.admission_date)}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Guardian</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.guardian_name || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Guardian Phone</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.guardian_phone || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Blood Group</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.blood_group || '-'}</p></div>
              <div><p className="text-xs text-gray-500 dark:text-gray-400">Address</p><p className="text-sm font-medium text-gray-900 dark:text-white">{viewModal.address || '-'}</p></div>
            </div>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleteId}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Delete Student"
        message="Are you sure you want to delete this student? This action cannot be undone."
        confirmText="Delete"
        loading={saving}
      />
    </div>
  );
}
