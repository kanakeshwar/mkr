import { useEffect, useState } from 'react';
import { Check, X, Clock, Save } from 'lucide-react';
import { supabase, type Student, type Subject } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Input';
import { Avatar } from '../../components/ui/Avatar';
import { useToast } from '../../components/ui/Toast';
import { cn } from '../../lib/utils';

export function AttendancePage() {
  const { teacher } = useAuth();
  const { toast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<Record<string, 'present' | 'absent' | 'late'>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchSubjects(); }, [teacher]);

  const fetchSubjects = async () => {
    if (!teacher) return;
    const { data } = await supabase
      .from('teacher_subjects')
      .select('subject:subjects(*)')
      .eq('teacher_id', teacher.id);
    setSubjects((data || []).map((d: any) => d.subject));
    setLoading(false);
  };

  const fetchStudents = async () => {
    if (!selectedSubject) return;
    setLoading(true);
    const subject = subjects.find((s) => s.id === selectedSubject);
    const { data } = await supabase
      .from('students')
      .select('*, profile:profiles(*)')
      .eq('course_id', subject?.course_id || '')
      .order('roll_number');
    setStudents(data || []);

    const { data: existing } = await supabase
      .from('attendance')
      .select('student_id, status')
      .eq('subject_id', selectedSubject)
      .eq('date', selectedDate);

    const attMap: Record<string, 'present' | 'absent' | 'late'> = {};
    (existing || []).forEach((a: any) => { attMap[a.student_id] = a.status; });
    setAttendance(attMap);
    setLoading(false);
  };

  useEffect(() => { if (selectedSubject) fetchStudents(); }, [selectedSubject, selectedDate]);

  const setStatus = (studentId: string, status: 'present' | 'absent' | 'late') => {
    setAttendance({ ...attendance, [studentId]: status });
  };

  const markAllPresent = () => {
    const allPresent: Record<string, 'present' | 'absent' | 'late'> = {};
    students.forEach((s) => { allPresent[s.id] = 'present'; });
    setAttendance(allPresent);
  };

  const handleSave = async () => {
    if (!teacher || !selectedSubject) return;
    setSaving(true);
    try {
      const records = students
        .filter((s) => attendance[s.id])
        .map((s) => ({
          student_id: s.id,
          subject_id: selectedSubject,
          date: selectedDate,
          status: attendance[s.id],
          marked_by: teacher.profile_id,
        }));

      if (records.length === 0) {
        toast('No attendance to save', 'warning');
        setSaving(false);
        return;
      }

      await supabase.from('attendance').delete().eq('subject_id', selectedSubject).eq('date', selectedDate);
      const { error } = await supabase.from('attendance').insert(records);
      if (error) throw error;
      toast('Attendance saved successfully', 'success');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const presentCount = Object.values(attendance).filter((s) => s === 'present').length;
  const absentCount = Object.values(attendance).filter((s) => s === 'absent').length;
  const lateCount = Object.values(attendance).filter((s) => s === 'late').length;

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Attendance Management" description="Mark and update student attendance" />

      <Card>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Select label="Subject" value={selectedSubject} onChange={(e) => setSelectedSubject(e.target.value)}>
              <option value="">Select Subject</option>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <div>
              <label className="label">Date</label>
              <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="input" />
            </div>
            <div className="flex items-end gap-2">
              <Button variant="outline" onClick={markAllPresent} disabled={!selectedSubject}>Mark All Present</Button>
              <Button onClick={handleSave} loading={saving} disabled={!selectedSubject}><Save className="w-4 h-4" /> Save</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedSubject && (
        <div className="grid grid-cols-3 gap-4">
          <Card><CardContent className="flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-success-100 dark:bg-success-900/30 flex items-center justify-center"><Check className="w-5 h-5 text-success-600" /></div><div><p className="text-2xl font-bold text-gray-900 dark:text-white">{presentCount}</p><p className="text-xs text-gray-500">Present</p></div></CardContent></Card>
          <Card><CardContent className="flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-error-100 dark:bg-error-900/30 flex items-center justify-center"><X className="w-5 h-5 text-error-600" /></div><div><p className="text-2xl font-bold text-gray-900 dark:text-white">{absentCount}</p><p className="text-xs text-gray-500">Absent</p></div></CardContent></Card>
          <Card><CardContent className="flex items-center gap-3"><div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center"><Clock className="w-5 h-5 text-warning-600" /></div><div><p className="text-2xl font-bold text-gray-900 dark:text-white">{lateCount}</p><p className="text-xs text-gray-500">Late</p></div></CardContent></Card>
        </div>
      )}

      {selectedSubject && (
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-6 space-y-3">
                {[...Array(5)].map((_, i) => <div key={i} className="skeleton h-16" />)}
              </div>
            ) : students.length === 0 ? (
              <div className="py-12 text-center text-gray-500">No students found for this subject</div>
            ) : (
              <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
                {students.map((s) => (
                  <div key={s.id} className="flex items-center gap-4 px-6 py-3.5">
                    <Avatar name={s.profile?.full_name || '?'} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{s.profile?.full_name}</p>
                      <p className="text-xs text-gray-500">{s.roll_number}</p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {(['present', 'absent', 'late'] as const).map((status) => (
                        <button
                          key={status}
                          onClick={() => setStatus(s.id, status)}
                          className={cn(
                            'px-3 py-1.5 rounded-lg text-xs font-medium transition-all',
                            attendance[s.id] === status
                              ? status === 'present' ? 'bg-success-500 text-white'
                                : status === 'absent' ? 'bg-error-500 text-white'
                                : 'bg-warning-500 text-white'
                              : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                          )}
                        >
                          {status === 'present' ? <Check className="w-3 h-3" /> : status === 'absent' ? <X className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
