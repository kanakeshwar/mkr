import { useEffect, useState } from 'react';
import { Eye, Mail, Phone } from 'lucide-react';
import { supabase, type Student } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { DataTable } from '../../components/ui/DataTable';
import { Modal } from '../../components/ui/Modal';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { formatDate } from '../../lib/utils';

export function TeacherStudentsPage() {
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewModal, setViewModal] = useState<Student | null>(null);

  useEffect(() => { fetchStudents(); }, []);

  const fetchStudents = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('students')
      .select('*, profile:profiles(*), department:departments(*), course:courses(*)')
      .order('roll_number');
    setStudents(data || []);
    setLoading(false);
  };

  const columns = [
    {
      key: 'name', header: 'Student', sortable: true, sortValue: (s: Student) => s.profile?.full_name || '',
      render: (s: Student) => (
        <div className="flex items-center gap-3">
          <Avatar name={s.profile?.full_name || '?'} src={s.profile?.avatar_url} size="sm" />
          <div>
            <p className="font-medium text-gray-900 dark:text-white">{s.profile?.full_name}</p>
            <p className="text-xs text-gray-500">{s.profile?.email}</p>
          </div>
        </div>
      ),
    },
    { key: 'roll_number', header: 'Roll No', sortable: true, sortValue: (s: Student) => s.roll_number, render: (s: Student) => <span className="font-mono text-sm">{s.roll_number}</span> },
    { key: 'department', header: 'Department', render: (s: Student) => <span className="text-sm">{s.department?.name || '-'}</span> },
    { key: 'course', header: 'Course', render: (s: Student) => <span className="text-sm">{s.course?.name || '-'}</span> },
    { key: 'semester', header: 'Semester', sortable: true, sortValue: (s: Student) => s.current_semester, render: (s: Student) => <Badge variant="info">Sem {s.current_semester}</Badge> },
    {
      key: 'actions', header: 'Actions',
      render: (s: Student) => (
        <button onClick={() => setViewModal(s)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-500"><Eye className="w-4 h-4" /></button>
      ),
    },
  ];

  return (
    <div className="animate-fade-in">
      <PageHeader title="Student List" description="View students across all departments" />
      <DataTable columns={columns} data={students} loading={loading} searchKeys={['roll_number']} searchPlaceholder="Search by roll number..." exportFilename="students" />

      <Modal open={!!viewModal} onClose={() => setViewModal(null)} title="Student Details" size="md">
        {viewModal && (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Avatar name={viewModal.profile?.full_name || '?'} src={viewModal.profile?.avatar_url} size="xl" />
              <div>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{viewModal.profile?.full_name}</h3>
                <p className="text-sm text-gray-500 flex items-center gap-1"><Mail className="w-3 h-3" /> {viewModal.profile?.email}</p>
                {viewModal.profile?.phone && <p className="text-sm text-gray-500 flex items-center gap-1"><Phone className="w-3 h-3" /> {viewModal.profile.phone}</p>}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-xs text-gray-500">Roll Number</p><p className="text-sm font-medium">{viewModal.roll_number}</p></div>
              <div><p className="text-xs text-gray-500">Department</p><p className="text-sm font-medium">{viewModal.department?.name || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Course</p><p className="text-sm font-medium">{viewModal.course?.name || '-'}</p></div>
              <div><p className="text-xs text-gray-500">Semester</p><p className="text-sm font-medium">Semester {viewModal.current_semester}</p></div>
              <div><p className="text-xs text-gray-500">Admission Date</p><p className="text-sm font-medium">{formatDate(viewModal.admission_date)}</p></div>
              <div><p className="text-xs text-gray-500">Guardian</p><p className="text-sm font-medium">{viewModal.guardian_name || '-'}</p></div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
