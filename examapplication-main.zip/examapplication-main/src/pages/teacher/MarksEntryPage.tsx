import { useEffect, useState } from 'react';
import { Save, Download } from 'lucide-react';
import { supabase, type Student, type Subject, type Exam } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Select } from '../../components/ui/Input';
import { Avatar } from '../../components/ui/Avatar';
import { Badge } from '../../components/ui/Badge';
import { useToast } from '../../components/ui/Toast';
import { calculateGrade, exportToCSV } from '../../lib/utils';

export function MarksEntryPage() {
  const { teacher } = useAuth();
  const { toast } = useToast();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [exams, setExams] = useState<Exam[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedExam, setSelectedExam] = useState('');
  const [marks, setMarks] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => { fetchSubjects(); }, [teacher]);

  const fetchSubjects = async () => {
    if (!teacher) return;
    const { data } = await supabase.from('teacher_subjects').select('subject:subjects(*)').eq('teacher_id', teacher.id);
    setSubjects((data || []).map((d: any) => d.subject));
    setLoading(false);
  };

  useEffect(() => {
    if (selectedSubject) {
      fetchExams();
      fetchStudents();
    }
  }, [selectedSubject]);

  const fetchExams = async () => {
    const { data } = await supabase.from('exams').select('*').eq('subject_id', selectedSubject).order('created_at', { ascending: false });
    setExams(data || []);
  };

  const fetchStudents = async () => {
    const subject = subjects.find((s) => s.id === selectedSubject);
    const { data } = await supabase
      .from('students')
      .select('*, profile:profiles(*)')
      .eq('course_id', subject?.course_id || '')
      .order('roll_number');
    setStudents(data || []);

    if (selectedExam) {
      const { data: existingMarks } = await supabase.from('marks').select('student_id, marks_obtained').eq('subject_id', selectedSubject).eq('exam_id', selectedExam);
      const marksMap: Record<string, string> = {};
      (existingMarks || []).forEach((m: any) => { marksMap[m.student_id] = m.marks_obtained.toString(); });
      setMarks(marksMap);
    } else {
      setMarks({});
    }
  };

  useEffect(() => { if (selectedSubject) fetchStudents(); }, [selectedExam]);

  const handleSave = async () => {
    if (!teacher || !selectedSubject) return;
    setSaving(true);
    try {
      const subject = subjects.find((s) => s.id === selectedSubject);
      const records = students
        .filter((s) => marks[s.id] !== undefined && marks[s.id] !== '')
        .map((s) => {
          const obtained = parseFloat(marks[s.id]);
          const total = subject?.total_marks || 100;
          const percentage = (obtained / total) * 100;
          return {
            student_id: s.id,
            subject_id: selectedSubject,
            exam_id: selectedExam || null,
            semester_id: subject?.semester_id || null,
            marks_obtained: obtained,
            total_marks: total,
            grade: calculateGrade(percentage),
            is_published: false,
            entered_by: teacher.profile_id,
          };
        });

      if (records.length === 0) {
        toast('No marks to save', 'warning');
        setSaving(false);
        return;
      }

      for (const record of records) {
        const { data: existing } = await supabase
          .from('marks')
          .select('id')
          .eq('student_id', record.student_id)
          .eq('subject_id', record.subject_id)
          .eq('exam_id', record.exam_id)
          .maybeSingle();

        if (existing) {
          await supabase.from('marks').update({
            marks_obtained: record.marks_obtained,
            grade: record.grade,
            entered_by: record.entered_by,
          }).eq('id', existing.id);
        } else {
          await supabase.from('marks').insert(record);
        }
      }

      toast('Marks saved successfully', 'success');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to save', 'error');
    }
    setSaving(false);
  };

  const handleExport = () => {
    const headers = ['Roll No', 'Student Name', 'Marks Obtained', 'Total Marks', 'Grade'];
    const subject = subjects.find((s) => s.id === selectedSubject);
    const rows = students.map((s) => {
      const obtained = parseFloat(marks[s.id] || '0');
      const total = subject?.total_marks || 100;
      return [s.roll_number, s.profile?.full_name || '', obtained, total, calculateGrade((obtained / total) * 100)];
    });
    exportToCSV('marks.csv', headers, rows);
    toast('Exported successfully', 'success');
  };

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Marks Entry" description="Enter and manage student marks" />

      <Card>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Select label="Subject" value={selectedSubject} onChange={(e) => setSelectedSubject(e.target.value)}>
              <option value="">Select Subject</option>
              {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </Select>
            <Select label="Exam" value={selectedExam} onChange={(e) => setSelectedExam(e.target.value)}>
              <option value="">Select Exam</option>
              {exams.map((e) => <option key={e.id} value={e.id}>{e.title}</option>)}
            </Select>
            <div className="flex items-end gap-2">
              <Button variant="outline" onClick={handleExport} disabled={!selectedSubject}><Download className="w-4 h-4" /> Export</Button>
              <Button onClick={handleSave} loading={saving} disabled={!selectedSubject}><Save className="w-4 h-4" /> Save</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {selectedSubject && (
        <Card>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-6 space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="skeleton h-16" />)}</div>
            ) : students.length === 0 ? (
              <div className="py-12 text-center text-gray-500">No students found</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Student</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Roll No</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Marks (out of {subjects.find((s) => s.id === selectedSubject)?.total_marks || 100})</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700/50">
                    {students.map((s) => {
                      const obtained = parseFloat(marks[s.id] || '0');
                      const total = subjects.find((sub) => sub.id === selectedSubject)?.total_marks || 100;
                      const grade = marks[s.id] ? calculateGrade((obtained / total) * 100) : '-';
                      return (
                        <tr key={s.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                          <td className="px-6 py-3.5">
                            <div className="flex items-center gap-3">
                              <Avatar name={s.profile?.full_name || '?'} size="sm" />
                              <span className="text-sm font-medium text-gray-900 dark:text-white">{s.profile?.full_name}</span>
                            </div>
                          </td>
                          <td className="px-6 py-3.5 text-sm text-gray-500">{s.roll_number}</td>
                          <td className="px-6 py-3.5">
                            <input
                              type="number"
                              value={marks[s.id] || ''}
                              onChange={(e) => setMarks({ ...marks, [s.id]: e.target.value })}
                              placeholder="0"
                              min="0"
                              max={total}
                              className="w-24 px-3 py-1.5 text-sm rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
                            />
                          </td>
                          <td className="px-6 py-3.5">
                            {grade !== '-' ? <Badge variant={grade === 'F' ? 'error' : 'success'}>{grade}</Badge> : <span className="text-gray-400">-</span>}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
