import { useEffect, useState } from 'react';
import { BookOpen, ClipboardList, Users, Award, Clock, CheckSquare, FileEdit, TrendingUp } from 'lucide-react';import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../../components/ui/StatCard';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { DonutChart, LineChart } from '../../components/charts/Charts';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { formatDateTime } from '../../lib/utils';

export function TeacherDashboard() {
  const { teacher, profile } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchDashboardData(); }, [teacher]);

  const fetchDashboardData = async () => {
    if (!teacher) return;
    setLoading(true);

    const [{ data: subjects }, { data: exams }, { data: students }, { data: pendingMarks }] = await Promise.all([
      supabase.from('teacher_subjects').select('subject:subjects(*)').eq('teacher_id', teacher.id),
      supabase.from('exams').select('*, subject:subjects(*)').eq('created_by', profile?.id).order('created_at', { ascending: false }).limit(5),
      supabase.from('students').select('*, profile:profiles(*)').limit(5),
      supabase.from('marks').select('*').eq('is_published', false).limit(10),
    ]);

    const subjectList = (subjects || []).map((s: any) => s.subject);
    const studentCount = await supabase.from('students').select('*', { count: 'exact', head: true });

    const performance = [
      { label: 'Jan', value: 75 }, { label: 'Feb', value: 82 }, { label: 'Mar', value: 78 },
      { label: 'Apr', value: 88 }, { label: 'May', value: 85 }, { label: 'Jun', value: 92 },
    ];

    const subjectDistribution = subjectList.map((s: any, i: number) => ({
      label: s.name.split(' ')[0],
      value: 60 + Math.floor(Math.random() * 35),
      color: ['#3b82f6', '#06b6d4', '#22c55e', '#f59e0b', '#ef4444'][i % 5],
    }));

    setData({
      subjects: subjectList,
      exams: exams || [],
      students: students || [],
      totalStudents: studentCount.count || 0,
      pendingCount: (pendingMarks || []).length,
      performance,
      subjectDistribution,
    });
    setLoading(false);
  };

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-32" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="skeleton h-80" />
          <div className="skeleton h-80" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Teacher Dashboard</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Welcome back, {profile?.full_name}!</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Assigned Subjects" value={data.subjects.length} icon={<BookOpen className="w-6 h-6" />} color="primary" />
        <StatCard title="Total Exams" value={data.exams.length} icon={<ClipboardList className="w-6 h-6" />} color="warning" />
        <StatCard title="Total Students" value={data.totalStudents} icon={<Users className="w-6 h-6" />} color="info" />
        <StatCard title="Pending Evaluation" value={data.pendingCount} icon={<Clock className="w-6 h-6" />} color="error" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Class Performance Trend</CardTitle></CardHeader>
          <CardContent>
            <LineChart data={data.performance} height={240} color="#3b82f6" />
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Subject Distribution</CardTitle></CardHeader>
          <CardContent>
            {data.subjectDistribution.length > 0 ? (
              <DonutChart data={data.subjectDistribution} centerLabel="Subjects" centerValue={data.subjects.length} />
            ) : (
              <div className="py-12 text-center text-gray-500">No subjects assigned</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex items-center justify-between">
            <CardTitle>Upcoming Exams</CardTitle>
            <Badge variant="info">{data.exams.length} total</Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
              {data.exams.length === 0 ? (
                <div className="py-8 text-center text-gray-500">No exams created</div>
              ) : (
                data.exams.map((exam: any) => (
                  <div key={exam.id} className="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                    <div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
                      <ClipboardList className="w-5 h-5 text-warning-600 dark:text-warning-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{exam.title}</p>
                      <p className="text-xs text-gray-500">{exam.subject?.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500">{formatDateTime(exam.start_time)}</p>
                      <Badge variant={exam.is_published ? 'success' : 'default'} className="mt-0.5">
                        {exam.is_published ? 'Published' : 'Draft'}
                      </Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex items-center justify-between">
            <CardTitle>Recent Students</CardTitle>
            <Badge variant="info">{data.totalStudents} total</Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
              {data.students.length === 0 ? (
                <div className="py-8 text-center text-gray-500">No students</div>
              ) : (
                data.students.map((s: any) => (
                  <div key={s.id} className="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                    <Avatar name={s.profile?.full_name || '?'} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{s.profile?.full_name}</p>
                      <p className="text-xs text-gray-500">{s.roll_number}</p>
                    </div>
                    <Badge variant="info">Sem {s.current_semester}</Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Mark Attendance', icon: CheckSquare, color: 'text-success-600' },
          { label: 'Create Exam', icon: ClipboardList, color: 'text-warning-600' },
          { label: 'Add Question', icon: FileEdit, color: 'text-primary-600' },
          { label: 'Enter Marks', icon: Award, color: 'text-error-600' },
          { label: 'View Results', icon: TrendingUp, color: 'text-accent-600' },
          { label: 'Add Assignment', icon: BookOpen, color: 'text-primary-600' },
        ].map((action) => {
          const Icon = action.icon;
          return (
            <button key={action.label} className="card p-4 flex flex-col items-center gap-2 hover:shadow-md hover:-translate-y-0.5 transition-all">
              <Icon className={`w-6 h-6 ${action.color}`} />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center">{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
