import { useEffect, useState } from 'react';
import { FileText, Upload, Plus, Clock, Award, Eye } from 'lucide-react';
import { supabase, type Assignment } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { Input, Select, Textarea } from '../../components/ui/Input';
import { useToast } from '../../components/ui/Toast';
import { timeAgo } from '../../lib/utils';

export function AssignmentsPage() {
  const { profile, teacher, student } = useAuth();
  const { toast } = useToast();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [submitModal, setSubmitModal] = useState<Assignment | null>(null);
  const [submissionText, setSubmissionText] = useState('');
  const [form, setForm] = useState({ title: '', description: '', subject_id: '', total_marks: '100', due_date: '' });
  const [subjects, setSubjects] = useState<any[]>([]);

  useEffect(() => { fetchAssignments(); fetchSubjects(); }, [profile]);

  const fetchAssignments = async () => {
    setLoading(true);
    const { data } = await supabase.from('assignments').select('*, subject:subjects(*)').order('created_at', { ascending: false });
    setAssignments(data || []);
    setLoading(false);
  };

  const fetchSubjects = async () => {
    if (teacher) {
      const { data } = await supabase.from('teacher_subjects').select('subject:subjects(*)').eq('teacher_id', teacher.id);
      setSubjects((data || []).map((d: any) => d.subject));
    } else {
      const { data } = await supabase.from('subjects').select('*');
      setSubjects(data || []);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase.from('assignments').insert({
        title: form.title, description: form.description, subject_id: form.subject_id,
        total_marks: parseInt(form.total_marks),
        due_date: form.due_date ? new Date(form.due_date).toISOString() : null,
        is_published: true, created_by: profile?.id,
      });
      if (error) throw error;
      toast('Assignment created', 'success');
      setModalOpen(false);
      setForm({ title: '', description: '', subject_id: '', total_marks: '100', due_date: '' });
      fetchAssignments();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to create', 'error');
    }
    setSaving(false);
  };

  const handleSubmit = async () => {
    if (!submitModal || !student) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('assignment_submissions').insert({
        assignment_id: submitModal.id, student_id: student.id,
        submission_text: submissionText, is_graded: false,
      });
      if (error) throw error;
      toast('Assignment submitted successfully', 'success');
      setSubmitModal(null);
      setSubmissionText('');
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to submit', 'error');
    }
    setSaving(false);
  };

  const isTeacher = profile?.role === 'teacher';

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Assignments" description={isTeacher ? 'Create and manage assignments' : 'View and submit assignments'} actions={isTeacher && <Button onClick={() => setModalOpen(true)}><Plus className="w-4 h-4" /> Create Assignment</Button>} />

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">{[...Array(4)].map((_, i) => <div key={i} className="skeleton h-40" />)}</div>
      ) : assignments.length === 0 ? (
        <Card><CardContent className="py-16 text-center">
          <FileText className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No assignments available</p>
        </CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {assignments.map((a) => (
            <Card key={a.id} className="hover:shadow-md transition-shadow">
              <CardContent>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                    <FileText className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <Badge variant={a.is_published ? 'success' : 'default'}>{a.is_published ? 'Published' : 'Draft'}</Badge>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{a.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">{a.description}</p>
                <div className="flex items-center gap-3 mt-4 text-xs text-gray-500">
                  <span className="flex items-center gap-1"><Award className="w-3 h-3" /> {a.total_marks} marks</span>
                  {a.due_date && <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Due {timeAgo(a.due_date)}</span>}
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <span className="text-xs text-gray-500">{a.subject?.name || 'General'}</span>
                  {isTeacher ? (
                    <Button size="sm" variant="outline"><Eye className="w-3.5 h-3.5" /> View Submissions</Button>
                  ) : (
                    <Button size="sm" onClick={() => setSubmitModal(a)}><Upload className="w-3.5 h-3.5" /> Submit</Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Create Assignment" size="md">
        <form onSubmit={handleSave} className="space-y-4">
          <Input label="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <Textarea label="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={3} />
          <Select label="Subject" value={form.subject_id} onChange={(e) => setForm({ ...form, subject_id: e.target.value })} required>
            <option value="">Select Subject</option>
            {subjects.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </Select>
          <div className="grid grid-cols-2 gap-4">
            <Input label="Total Marks" type="number" value={form.total_marks} onChange={(e) => setForm({ ...form, total_marks: e.target.value })} required />
            <Input label="Due Date" type="datetime-local" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
          </div>
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button type="submit" loading={saving}>Create</Button>
          </div>
        </form>
      </Modal>

      <Modal open={!!submitModal} onClose={() => setSubmitModal(null)} title={`Submit: ${submitModal?.title || ''}`} size="md">
        <div className="space-y-4">
          <Textarea label="Your Submission" value={submissionText} onChange={(e) => setSubmissionText(e.target.value)} rows={6} placeholder="Enter your assignment submission here..." />
          <div className="flex justify-end gap-3">
            <Button variant="outline" onClick={() => setSubmitModal(null)}>Cancel</Button>
            <Button onClick={handleSubmit} loading={saving}><Upload className="w-4 h-4" /> Submit Assignment</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
