import { useState } from 'react';
import { Mail, Phone, MapPin, Calendar, User, Save, Camera, Lock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { supabase } from '../../lib/supabase';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Input, Select } from '../../components/ui/Input';
import { Avatar } from '../../components/ui/Avatar';
import { Badge } from '../../components/ui/Badge';
import { useToast } from '../../components/ui/Toast';
import { formatDate } from '../../lib/utils';

export function ProfilePage() {
  const { profile, student, teacher, refreshProfile } = useAuth();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [passwordModal, setPasswordModal] = useState(false);
  const [form, setForm] = useState({
    full_name: profile?.full_name || '',
    phone: profile?.phone || '',
    address: profile?.address || '',
    date_of_birth: profile?.date_of_birth || '',
    gender: profile?.gender || '',
  });
  const [passwords, setPasswords] = useState({ current: '', new: '', confirm: '' });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const { error } = await supabase.from('profiles').update({
        full_name: form.full_name,
        phone: form.phone || null,
        address: form.address || null,
        date_of_birth: form.date_of_birth || null,
        gender: (form.gender as 'male' | 'female' | 'other') || null,
      }).eq('id', profile?.id);
      if (error) throw error;
      toast('Profile updated successfully', 'success');
      setEditing(false);
      refreshProfile();
    } catch (err) {
      toast(err instanceof Error ? err.message : 'Failed to update', 'error');
    }
    setSaving(false);
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (passwords.new !== passwords.confirm) {
      toast('Passwords do not match', 'error');
      return;
    }
    if (passwords.new.length < 6) {
      toast('Password must be at least 6 characters', 'error');
      return;
    }
    setSaving(true);
    const { error } = await supabase.auth.updateUser({ password: passwords.new });
    if (error) {
      toast(error.message, 'error');
    } else {
      toast('Password updated successfully', 'success');
      setPasswordModal(false);
      setPasswords({ current: '', new: '', confirm: '' });
    }
    setSaving(false);
  };

  if (!profile) return null;

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="My Profile" description="View and update your personal information" actions={
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setPasswordModal(true)}><Lock className="w-4 h-4" /> Change Password</Button>
          {!editing ? (
            <Button onClick={() => setEditing(true)}>Edit Profile</Button>
          ) : (
            <>
              <Button variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
              <Button onClick={handleSave} loading={saving}><Save className="w-4 h-4" /> Save</Button>
            </>
          )}
        </div>
      } />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardContent className="flex flex-col items-center text-center py-8">
            <div className="relative">
              <Avatar name={profile.full_name} src={profile.avatar_url} size="xl" />
              <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center shadow-lg hover:bg-primary-700">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white mt-4">{profile.full_name}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400">{profile.email}</p>
            <Badge variant="primary" className="mt-2 capitalize">{profile.role}</Badge>
            <div className="w-full mt-6 pt-6 border-t border-gray-100 dark:border-gray-700 space-y-3">
              {student && (
                <>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Roll Number</span>
                    <span className="font-medium text-gray-900 dark:text-white">{student.roll_number}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Semester</span>
                    <span className="font-medium text-gray-900 dark:text-white">Semester {student.current_semester}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Department</span>
                    <span className="font-medium text-gray-900 dark:text-white">{student.department?.name || '-'}</span>
                  </div>
                </>
              )}
              {teacher && (
                <>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Employee ID</span>
                    <span className="font-medium text-gray-900 dark:text-white">{teacher.employee_id}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Designation</span>
                    <span className="font-medium text-gray-900 dark:text-white">{teacher.designation}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-500">Department</span>
                    <span className="font-medium text-gray-900 dark:text-white">{teacher.department?.name || '-'}</span>
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Personal Information</CardTitle></CardHeader>
          <CardContent>
            {editing ? (
              <form onSubmit={handleSave} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="Full Name" value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} required />
                  <Input label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  <Input label="Date of Birth" type="date" value={form.date_of_birth} onChange={(e) => setForm({ ...form, date_of_birth: e.target.value })} />
                  <Select label="Gender" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                    <option value="">Select</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </Select>
                </div>
                <Input label="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </form>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center"><User className="w-5 h-5 text-primary-600" /></div>
                  <div><p className="text-xs text-gray-500">Full Name</p><p className="text-sm font-medium text-gray-900 dark:text-white">{profile.full_name}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent-100 dark:bg-accent-900/30 flex items-center justify-center"><Mail className="w-5 h-5 text-accent-600" /></div>
                  <div><p className="text-xs text-gray-500">Email</p><p className="text-sm font-medium text-gray-900 dark:text-white">{profile.email}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-success-100 dark:bg-success-900/30 flex items-center justify-center"><Phone className="w-5 h-5 text-success-600" /></div>
                  <div><p className="text-xs text-gray-500">Phone</p><p className="text-sm font-medium text-gray-900 dark:text-white">{profile.phone || 'Not set'}</p></div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center"><Calendar className="w-5 h-5 text-warning-600" /></div>
                  <div><p className="text-xs text-gray-500">Date of Birth</p><p className="text-sm font-medium text-gray-900 dark:text-white">{profile.date_of_birth ? formatDate(profile.date_of_birth) : 'Not set'}</p></div>
                </div>
                <div className="flex items-center gap-3 sm:col-span-2">
                  <div className="w-10 h-10 rounded-lg bg-error-100 dark:bg-error-900/30 flex items-center justify-center"><MapPin className="w-5 h-5 text-error-600" /></div>
                  <div><p className="text-xs text-gray-500">Address</p><p className="text-sm font-medium text-gray-900 dark:text-white">{profile.address || 'Not set'}</p></div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {passwordModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setPasswordModal(false)} />
          <Card className="relative w-full max-w-md animate-scale-in">
            <CardHeader><CardTitle>Change Password</CardTitle></CardHeader>
            <CardContent>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <Input label="New Password" type="password" value={passwords.new} onChange={(e) => setPasswords({ ...passwords, new: e.target.value })} required />
                <Input label="Confirm Password" type="password" value={passwords.confirm} onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })} required />
                <div className="flex justify-end gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setPasswordModal(false)}>Cancel</Button>
                  <Button type="submit" loading={saving}>Update Password</Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
