import { useState } from 'react';
import { GraduationCap, Mail, Lock, User, ArrowRight, Shield, BookOpen, Users } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../components/ui/Toast';
import { Button } from '../../components/ui/Button';
import type { UserRole } from '../../lib/supabase';
import { cn } from '../../lib/utils';

type SignupPageProps = {
  onNavigate: (path: string) => void;
};

export function SignupPage({ onNavigate }: SignupPageProps) {
  const { signUp } = useAuth();
  const { toast } = useToast();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password.length < 6) {
      toast('Password must be at least 6 characters', 'error');
      return;
    }
    setLoading(true);
    const { error } = await signUp(email, password, fullName, role);
    if (error) {
      toast(error, 'error');
    } else {
      toast('Account created successfully!', 'success');
    }
    setLoading(false);
  };

  const roles: { value: UserRole; label: string; icon: typeof Shield; desc: string }[] = [
    { value: 'student', label: 'Student', icon: Users, desc: 'Take exams and view results' },
    { value: 'teacher', label: 'Teacher', icon: BookOpen, desc: 'Manage exams and grades' },
    { value: 'admin', label: 'Admin', icon: Shield, desc: 'Full system access' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-950 dark:to-gray-900">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center gap-3 mb-8">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg shadow-primary-600/20">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-gray-900 dark:text-white">College EMS</h1>
            <p className="text-xs text-gray-500 dark:text-gray-400">Create your account</p>
          </div>
        </div>

        <div className="card p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">Get started</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">Create your account to join the platform</p>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="label">I am a</label>
              <div className="grid grid-cols-3 gap-2">
                {roles.map((r) => {
                  const Icon = r.icon;
                  return (
                    <button
                      key={r.value}
                      type="button"
                      onClick={() => setRole(r.value)}
                      className={cn(
                        'p-3 rounded-lg border-2 text-center transition-all',
                        role === r.value
                          ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                          : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                      )}
                    >
                      <Icon className={cn('w-5 h-5 mx-auto mb-1.5', role === r.value ? 'text-primary-600 dark:text-primary-400' : 'text-gray-400')} />
                      <p className={cn('text-xs font-medium', role === r.value ? 'text-primary-700 dark:text-primary-300' : 'text-gray-600 dark:text-gray-400')}>{r.label}</p>
                    </button>
                  );
                })}
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">{roles.find((r) => r.value === role)?.desc}</p>
            </div>

            <div>
              <label className="label">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="John Doe"
                  required
                  className="input pl-10"
                />
              </div>
            </div>

            <div>
              <label className="label">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@college.edu"
                  required
                  className="input pl-10"
                />
              </div>
            </div>

            <div>
              <label className="label">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Min. 6 characters"
                  required
                  className="input pl-10"
                />
              </div>
            </div>

            <Button type="submit" loading={loading} className="w-full" size="lg">
              Create Account <ArrowRight className="w-4 h-4" />
            </Button>
          </form>

          <p className="text-center text-sm text-gray-500 dark:text-gray-400 mt-6">
            Already have an account?{' '}
            <button onClick={() => onNavigate('/login')} className="text-primary-600 dark:text-primary-400 font-medium hover:underline">
              Sign in
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
