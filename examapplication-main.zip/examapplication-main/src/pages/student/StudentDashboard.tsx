import { useEffect, useState } from 'react';
import { BookOpen, Award, ClipboardList, CheckSquare, Calendar, Bell, FileText } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { StatCard } from '../../components/ui/StatCard';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { BarChart, ProgressRing } from '../../components/charts/Charts';
import { Badge } from '../../components/ui/Badge';
import { Avatar } from '../../components/ui/Avatar';
import { calculateSGPA, formatDateTime, timeAgo } from '../../lib/utils';

export function StudentDashboard() {
  const { student, profile } = useAuth();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchDashboardData(); }, [student]);

  const fetchDashboardData = async () => {
    if (!student) return;
    setLoading(true);

    const [
      { data: subjects },
      { data: exams },
      { data: marks },
      { data: attendance },
      { data: notifications },
    ] = await Promise.all([
      supabase.from('subjects').select('*').eq('semester_id', student.semester_id),
      supabase.from('exams').select('*, subject:subjects(*)').eq('is_published', true).eq('semester_id', student.semester_id).order('start_time', { ascending: true }).limit(5),
      supabase.from('marks').select('*, subject:subjects(*), exam:exams(*)').eq('student_id', student.id),
      supabase.from('attendance').select('status').eq('student_id', student.id),
      supabase.from('notifications').select('*').eq('user_id', profile?.id).order('created_at', { ascending: false }).limit(5),
    ]);

    const presentCount = (attendance || []).filter((a: any) => a.status === 'present').length;
    const totalCount = (attendance || []).length;
    const attendancePct = totalCount > 0 ? Math.round((presentCount / totalCount) * 100) : 0;

    const marksWithCredits = (marks || []).map((m: any) => ({
      marks_obtained: m.marks_obtained,
      total_marks: m.total_marks,
      credits: m.subject?.credits || 4,
    }));
    const sgpa = calculateSGPA(marksWithCredits);

    const subjectMarks = (marks || []).map((m: any) => ({
      label: m.subject?.name?.split(' ')[0] || 'Sub',
      value: Math.round((m.marks_obtained / m.total_marks) * 100),
    }));

    setData({
      subjects: subjects || [],
      exams: exams || [],
      marks: marks || [],
      notifications: notifications || [],
      attendancePct,
      sgpa: sgpa.toFixed(2),
      subjectMarks,
      presentCount,
      totalCount,
    });
    setLoading(false);
  };

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-32" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="skeleton h-80" />
          <div className="skeleton h-80" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center gap-4">
        <Avatar name={profile?.full_name || '?'} src={profile?.avatar_url} size="lg" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Welcome, {profile?.full_name?.split(' ')[0]}!</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">{student?.course?.name} • Semester {student?.current_semester}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Enrolled Subjects" value={data.subjects.length} icon={<BookOpen className="w-6 h-6" />} color="primary" />
        <StatCard title="Upcoming Exams" value={data.exams.length} icon={<ClipboardList className="w-6 h-6" />} color="warning" />
        <StatCard title="Attendance" value={`${data.attendancePct}%`} icon={<CheckSquare className="w-6 h-6" />} color="success" />
        <StatCard title="SGPA" value={data.sgpa} icon={<Award className="w-6 h-6" />} color="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Subject Performance</CardTitle></CardHeader>
          <CardContent>
            {data.subjectMarks.length > 0 ? (
              <BarChart data={data.subjectMarks} height={240} />
            ) : (
              <div className="py-12 text-center text-gray-500">No marks recorded yet</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Attendance</CardTitle></CardHeader>
          <CardContent className="flex items-center justify-center">
            <ProgressRing value={data.attendancePct} size={160} thickness={14} color="#22c55e" label="Present" />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex items-center justify-between">
            <CardTitle>Upcoming Exams</CardTitle>
            <Badge variant="warning">{data.exams.length}</Badge>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
              {data.exams.length === 0 ? (
                <div className="py-8 text-center text-gray-500">No upcoming exams</div>
              ) : (
                data.exams.map((exam: any) => (
                  <div key={exam.id} className="flex items-center gap-3 px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                    <div className="w-10 h-10 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
                      <ClipboardList className="w-5 h-5 text-warning-600 dark:text-warning-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{exam.title}</p>
                      <p className="text-xs text-gray-500">{exam.subject?.name}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-gray-500">{formatDateTime(exam.start_time)}</p>
                      <Badge variant="info" className="mt-0.5">{exam.duration_minutes}m</Badge>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex items-center justify-between">
            <CardTitle>Recent Notifications</CardTitle>
            <Bell className="w-5 h-5 text-gray-400" />
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
              {data.notifications.length === 0 ? (
                <div className="py-8 text-center text-gray-500">No notifications</div>
              ) : (
                data.notifications.map((n: any) => (
                  <div key={n.id} className="px-6 py-3.5 hover:bg-gray-50 dark:hover:bg-gray-700/30">
                    <div className="flex items-start gap-2">
                      <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.is_read ? 'bg-gray-300' : 'bg-primary-500'}`} />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{n.title}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 line-clamp-2">{n.message}</p>
                        <p className="text-xs text-gray-400 mt-1">{timeAgo(n.created_at)}</p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'View Subjects', icon: BookOpen, color: 'text-primary-600' },
          { label: 'Take Test', icon: ClipboardList, color: 'text-warning-600' },
          { label: 'Results', icon: Award, color: 'text-success-600' },
          { label: 'Attendance', icon: CheckSquare, color: 'text-accent-600' },
          { label: 'Assignments', icon: FileText, color: 'text-error-600' },
          { label: 'Schedule', icon: Calendar, color: 'text-primary-600' },
        ].map((action) => {
          const Icon = action.icon;
          return (
            <button key={action.label} className="card p-4 flex flex-col items-center gap-2 hover:shadow-md hover:-translate-y-0.5 transition-all">
              <Icon className={`w-6 h-6 ${action.color}`} />
              <span className="text-xs font-medium text-gray-700 dark:text-gray-300 text-center">{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
