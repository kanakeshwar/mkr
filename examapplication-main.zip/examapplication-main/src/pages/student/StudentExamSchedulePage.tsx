import { useEffect, useState } from 'react';
import { Clock, Award, Calendar, ClipboardList } from 'lucide-react';
import { supabase, type Exam } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { formatDateTime } from '../../lib/utils';

export function StudentExamSchedulePage() {
  const { student } = useAuth();
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchExams(); }, [student]);

  const fetchExams = async () => {
    if (!student) return;
    const { data } = await supabase
      .from('exams')
      .select('*, subject:subjects(*)')
      .eq('is_published', true)
      .eq('semester_id', student.semester_id)
      .order('start_time', { ascending: true });
    setExams(data || []);
    setLoading(false);
  };

  if (loading) {
    return <div className="space-y-4">{[...Array(4)].map((_, i) => <div key={i} className="skeleton h-24" />)}</div>;
  }

  const now = new Date();
  const upcoming = exams.filter((e) => e.start_time && new Date(e.start_time) > now);
  const past = exams.filter((e) => e.end_time && new Date(e.end_time) < now);
  const ongoing = exams.filter((e) => {
    const start = e.start_time ? new Date(e.start_time) : null;
    const end = e.end_time ? new Date(e.end_time) : null;
    return start && end && start <= now && end >= now;
  });

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Exam Schedule" description="View your upcoming and past examinations" />

      {ongoing.length > 0 && (
        <Card className="border-success-200 dark:border-success-800">
          <CardContent>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2 h-2 rounded-full bg-success-500 animate-pulse" />
              <h3 className="font-semibold text-success-700 dark:text-success-400">Ongoing Exams</h3>
            </div>
            <div className="space-y-3">
              {ongoing.map((exam) => (
                <div key={exam.id} className="flex items-center gap-4 p-4 rounded-lg bg-success-50 dark:bg-success-900/20">
                  <div className="w-12 h-12 rounded-lg bg-success-500 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 dark:text-white">{exam.title}</p>
                    <p className="text-sm text-gray-500">{exam.subject?.name}</p>
                  </div>
                  <Badge variant="success">Live Now</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div>
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Upcoming Exams</h3>
        {upcoming.length === 0 ? (
          <Card><CardContent className="py-8 text-center text-gray-500">No upcoming exams scheduled</CardContent></Card>
        ) : (
          <div className="space-y-3">
            {upcoming.map((exam) => (
              <Card key={exam.id} className="hover:shadow-md transition-shadow">
                <CardContent className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-warning-600 dark:text-warning-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 dark:text-white">{exam.title}</p>
                    <p className="text-sm text-gray-500">{exam.subject?.name}</p>
                  </div>
                  <div className="hidden sm:flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1"><Calendar className="w-4 h-4" /> {formatDateTime(exam.start_time)}</span>
                    <span className="flex items-center gap-1"><Clock className="w-4 h-4" /> {exam.duration_minutes}m</span>
                    <span className="flex items-center gap-1"><Award className="w-4 h-4" /> {exam.total_marks}</span>
                  </div>
                  <Badge variant="warning">Upcoming</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {past.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Past Exams</h3>
          <div className="space-y-3">
            {past.map((exam) => (
              <Card key={exam.id} className="opacity-60">
                <CardContent className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-gray-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 dark:text-white">{exam.title}</p>
                    <p className="text-sm text-gray-500">{exam.subject?.name}</p>
                  </div>
                  <Badge variant="default">Completed</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
