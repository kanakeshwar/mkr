import { useEffect, useState } from 'react';
import { Bell, Check, Trash2, Info, CheckCircle, AlertCircle, Award, ClipboardList } from 'lucide-react';
import { supabase, type Notification } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { useToast } from '../../components/ui/Toast';
import { cn, timeAgo } from '../../lib/utils';

export function StudentNotificationsPage() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchNotifications(); }, [profile]);

  const fetchNotifications = async () => {
    if (!profile) return;
    const { data } = await supabase.from('notifications').select('*').eq('user_id', profile.id).order('created_at', { ascending: false });
    setNotifications(data || []);
    setLoading(false);
  };

  const markAsRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications(notifications.map((n) => n.id === id ? { ...n, is_read: true } : n));
  };

  const markAllRead = async () => {
    if (!profile) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', profile.id).eq('is_read', false);
    setNotifications(notifications.map((n) => ({ ...n, is_read: true })));
    toast('All notifications marked as read', 'success');
  };

  const deleteNotification = async (id: string) => {
    await supabase.from('notifications').delete().eq('id', id);
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  const icons = {
    info: Info, success: CheckCircle, warning: AlertCircle, error: AlertCircle,
    exam: ClipboardList, result: Award,
  };

  const colors = {
    info: 'bg-accent-100 dark:bg-accent-900/30 text-accent-600 dark:text-accent-400',
    success: 'bg-success-100 dark:bg-success-900/30 text-success-600 dark:text-success-400',
    warning: 'bg-warning-100 dark:bg-warning-900/30 text-warning-600 dark:text-warning-400',
    error: 'bg-error-100 dark:bg-error-900/30 text-error-600 dark:text-error-400',
    exam: 'bg-primary-100 dark:bg-primary-900/30 text-primary-600 dark:text-primary-400',
    result: 'bg-success-100 dark:bg-success-900/30 text-success-600 dark:text-success-400',
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  if (loading) {
    return <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="skeleton h-20" />)}</div>;
  }

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="Notifications" description={`${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`} actions={
        unreadCount > 0 ? <Button variant="outline" onClick={markAllRead}><Check className="w-4 h-4" /> Mark All Read</Button> : undefined
      } />

      {notifications.length === 0 ? (
        <Card><CardContent className="py-16 text-center">
          <Bell className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No notifications yet</p>
        </CardContent></Card>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => {
            const Icon = icons[n.type] || Info;
            return (
              <Card key={n.id} className={cn('hover:shadow-md transition-shadow', !n.is_read && 'border-l-4 border-l-primary-500')}>
                <CardContent className="flex items-start gap-4">
                  <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0', colors[n.type])}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold text-gray-900 dark:text-white">{n.title}</p>
                      {!n.is_read && <span className="w-2 h-2 rounded-full bg-primary-500" />}
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{n.message}</p>
                    <p className="text-xs text-gray-400 mt-2">{timeAgo(n.created_at)}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    {!n.is_read && (
                      <button onClick={() => markAsRead(n.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400" title="Mark as read">
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    <button onClick={() => deleteNotification(n.id)} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-error-400" title="Delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
