import { useEffect, useState } from 'react';
import { Check, X, Clock, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';
import { StatCard } from '../../components/ui/StatCard';
import { ProgressRing } from '../../components/charts/Charts';
import { formatDate } from '../../lib/utils';

export function StudentAttendancePage() {
  const { student } = useAuth();
  const [attendance, setAttendance] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ present: 0, absent: 0, late: 0, total: 0, percentage: 0 });

  useEffect(() => { fetchAttendance(); }, [student]);

  const fetchAttendance = async () => {
    if (!student) return;
    const { data } = await supabase
      .from('attendance')
      .select('*, subject:subjects(*)')
      .eq('student_id', student.id)
      .order('date', { ascending: false });
    const records = data || [];
    setAttendance(records);
    const present = records.filter((a) => a.status === 'present').length;
    const absent = records.filter((a) => a.status === 'absent').length;
    const late = records.filter((a) => a.status === 'late').length;
    const total = records.length;
    const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
    setStats({ present, absent, late, total, percentage });
    setLoading(false);
  };

  if (loading) {
    return <div className="space-y-6"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4">{[...Array(3)].map((_, i) => <div key={i} className="skeleton h-32" />)}</div><div className="skeleton h-96" /></div>;
  }

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader title="My Attendance" description="View your attendance records" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard title="Present" value={stats.present} icon={<Check className="w-6 h-6" />} color="success" />
        <StatCard title="Absent" value={stats.absent} icon={<X className="w-6 h-6" />} color="error" />
        <StatCard title="Late" value={stats.late} icon={<Clock className="w-6 h-6" />} color="warning" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <CardContent className="flex items-center justify-center">
            <ProgressRing value={stats.percentage} size={160} thickness={14} color="#22c55e" label="Attendance" />
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardContent className="p-0">
            <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
              <h3 className="font-semibold text-gray-900 dark:text-white">Attendance History</h3>
            </div>
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50 max-h-96 overflow-y-auto">
              {attendance.length === 0 ? (
                <div className="py-8 text-center text-gray-500">No attendance records</div>
              ) : (
                attendance.map((a) => (
                  <div key={a.id} className="flex items-center gap-4 px-6 py-3.5">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      a.status === 'present' ? 'bg-success-100 dark:bg-success-900/30' :
                      a.status === 'absent' ? 'bg-error-100 dark:bg-error-900/30' :
                      'bg-warning-100 dark:bg-warning-900/30'
                    }`}>
                      {a.status === 'present' ? <Check className="w-5 h-5 text-success-600" /> :
                        a.status === 'absent' ? <X className="w-5 h-5 text-error-600" /> :
                        <Clock className="w-5 h-5 text-warning-600" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{a.subject?.name || 'General'}</p>
                      <p className="text-xs text-gray-500 flex items-center gap-1"><Calendar className="w-3 h-3" /> {formatDate(a.date)}</p>
                    </div>
                    <Badge variant={a.status === 'present' ? 'success' : a.status === 'absent' ? 'error' : 'warning'} className="capitalize">
                      {a.status}
                    </Badge>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
