import { useEffect, useState, useCallback } from 'react';
import { Clock, ClipboardList, Play, Award, CheckCircle, AlertCircle, ArrowLeft, ArrowRight, Flag } from 'lucide-react';
import { supabase, type Exam, type Question, type Option } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { useToast } from '../../components/ui/Toast';
import { formatDateTime, cn, calculateGrade } from '../../lib/utils';

type ExamWithQuestions = Exam & { questions: (Question & { options: Option[] })[] };

export function OnlineTestPage() {
  const { student } = useAuth();
  const { toast } = useToast();
  const [exams, setExams] = useState<Exam[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeExam, setActiveExam] = useState<ExamWithQuestions | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeLeft, setTimeLeft] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [result, setResult] = useState<{ score: number; total: number; percentage: number; grade: string; correct: number; wrong: number } | null>(null);
  const [confirmSubmit, setConfirmSubmit] = useState(false);

  useEffect(() => { fetchExams(); }, []);

  const fetchExams = async () => {
    if (!student) return;
    setLoading(true);
    const { data } = await supabase
      .from('exams')
      .select('*, subject:subjects(*)')
      .eq('is_published', true)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    setExams(data || []);
    setLoading(false);
  };

  const startExam = async (exam: Exam) => {
    const { data: eq } = await supabase
      .from('exam_questions')
      .select('question:questions(*, options(*))')
      .eq('exam_id', exam.id)
      .order('question_order');

    const questions = (eq || []).map((e: any) => e.question).filter(Boolean);
    if (questions.length === 0) {
      toast('This exam has no questions yet', 'error');
      return;
    }

    setActiveExam({ ...exam, questions });
    setCurrentQ(0);
    setAnswers({});
    setTimeLeft(exam.duration_minutes * 60);
    setShowResults(false);
    setResult(null);
  };

  const selectAnswer = (questionId: string, optionId: string) => {
    setAnswers({ ...answers, [questionId]: optionId });
  };

  const submitExam = useCallback(async () => {
    if (!activeExam || !student) return;
    setConfirmSubmit(false);

    let correct = 0;
    let wrong = 0;
    let score = 0;
    const total = activeExam.total_marks;
    const negativeMarking = activeExam.negative_marking || 0;

    for (const q of activeExam.questions) {
      const selectedOptionId = answers[q.id];
      if (!selectedOptionId) continue;

      const correctOption = q.options?.find((o) => o.is_correct);
      const isCorrect = selectedOptionId === correctOption?.id;

      if (isCorrect) {
        correct++;
        score += q.marks;
      } else {
        wrong++;
        score -= negativeMarking;
      }

      await supabase.from('student_answers').insert({
        exam_id: activeExam.id,
        question_id: q.id,
        student_id: student.id,
        selected_option_id: selectedOptionId,
        is_correct: isCorrect,
        marks_awarded: isCorrect ? q.marks : -negativeMarking,
        evaluated_at: new Date().toISOString(),
      });
    }

    const finalScore = Math.max(0, score);
    const percentage = Math.round((finalScore / total) * 100);
    const grade = calculateGrade(percentage);
    const isPassed = percentage >= activeExam.passing_marks / activeExam.total_marks * 100;

    await supabase.from('results').insert({
      exam_id: activeExam.id,
      student_id: student.id,
      total_marks_obtained: finalScore,
      total_marks_possible: total,
      percentage,
      grade,
      is_passed: isPassed,
      is_published: true,
      evaluated_at: new Date().toISOString(),
      published_at: new Date().toISOString(),
    });

    setResult({ score: finalScore, total, percentage, grade, correct, wrong });
    setShowResults(true);
    setActiveExam(null);
  }, [activeExam, answers, student]);

  useEffect(() => {
    if (!activeExam || timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          submitExam();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [activeExam, timeLeft, submitExam]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  if (showResults && result) {
    return (
      <div className="animate-fade-in max-w-2xl mx-auto">
        <Card className="text-center p-8">
          <div className={cn('w-20 h-20 rounded-full mx-auto flex items-center justify-center mb-4', result.percentage >= 40 ? 'bg-success-100 dark:bg-success-900/30' : 'bg-error-100 dark:bg-error-900/30')}>
            {result.percentage >= 40 ? <CheckCircle className="w-10 h-10 text-success-600 dark:text-success-400" /> : <AlertCircle className="w-10 h-10 text-error-600 dark:text-error-400" />}
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{result.percentage >= 40 ? 'Congratulations!' : 'Keep trying!'}</h2>
          <p className="text-gray-500 dark:text-gray-400 mt-1">You have completed the exam</p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
            <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{result.score}</p>
              <p className="text-xs text-gray-500">Score</p>
            </div>
            <div className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
              <p className="text-2xl font-bold text-gray-900 dark:text-white">{result.percentage}%</p>
              <p className="text-xs text-gray-500">Percentage</p>
            </div>
            <div className="p-4 rounded-lg bg-success-50 dark:bg-success-900/20">
              <p className="text-2xl font-bold text-success-600 dark:text-success-400">{result.correct}</p>
              <p className="text-xs text-gray-500">Correct</p>
            </div>
            <div className="p-4 rounded-lg bg-error-50 dark:bg-error-900/20">
              <p className="text-2xl font-bold text-error-600 dark:text-error-400">{result.wrong}</p>
              <p className="text-xs text-gray-500">Wrong</p>
            </div>
          </div>

          <div className="mt-6">
            <Badge variant={result.percentage >= 40 ? 'success' : 'error'} className="text-base px-4 py-1.5">
              Grade: {result.grade}
            </Badge>
          </div>

          <Button onClick={() => { setShowResults(false); fetchExams(); }} className="mt-6">
            Back to Exams
          </Button>
        </Card>
      </div>
    );
  }

  if (activeExam) {
    const question = activeExam.questions[currentQ];
    const totalQuestions = activeExam.questions.length;
    const progress = ((currentQ + 1) / totalQuestions) * 100;

    return (
      <div className="animate-fade-in max-w-4xl mx-auto">
        <Card>
          <CardHeader className="flex items-center justify-between">
            <div>
              <CardTitle>{activeExam.title}</CardTitle>
              <p className="text-sm text-gray-500 mt-1">{activeExam.subject?.name}</p>
            </div>
            <div className={cn('flex items-center gap-2 px-4 py-2 rounded-lg font-mono font-bold', timeLeft < 60 ? 'bg-error-100 text-error-700 dark:bg-error-900/30 dark:text-error-400' : 'bg-warning-100 text-warning-700 dark:bg-warning-900/30 dark:text-warning-400')}>
              <Clock className="w-5 h-5" />
              {formatTime(timeLeft)}
            </div>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Question {currentQ + 1} of {totalQuestions}</span>
                <span className="text-sm text-gray-500">{Object.keys(answers).length} answered</span>
              </div>
              <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                <div className="h-full bg-primary-500 transition-all duration-300" style={{ width: `${progress}%` }} />
              </div>
            </div>

            <div className="space-y-4">
              <div className="p-5 rounded-lg bg-gray-50 dark:bg-gray-800">
                <div className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-8 h-8 rounded-lg bg-primary-500 text-white flex items-center justify-center font-bold text-sm">
                    {currentQ + 1}
                  </span>
                  <p className="text-base font-medium text-gray-900 dark:text-white pt-1">{question.question_text}</p>
                </div>
                <div className="flex items-center gap-2 mt-3 ml-11">
                  <Badge variant={question.difficulty === 'easy' ? 'success' : question.difficulty === 'medium' ? 'warning' : 'error'}>{question.difficulty}</Badge>
                  <span className="text-xs text-gray-500">{question.marks} marks</span>
                </div>
              </div>

              <div className="space-y-2">
                {question.options?.map((opt, i) => (
                  <button
                    key={opt.id}
                    onClick={() => selectAnswer(question.id, opt.id)}
                    className={cn(
                      'w-full flex items-center gap-3 p-4 rounded-lg border-2 text-left transition-all',
                      answers[question.id] === opt.id
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    )}
                  >
                    <div className={cn(
                      'w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0',
                      answers[question.id] === opt.id ? 'border-primary-500 bg-primary-500' : 'border-gray-300 dark:border-gray-600'
                    )}>
                      {answers[question.id] === opt.id && <div className="w-2.5 h-2.5 rounded-full bg-white" />}
                    </div>
                    <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{String.fromCharCode(65 + i)}. {opt.option_text}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between mt-6">
              <Button
                variant="outline"
                onClick={() => setCurrentQ(Math.max(0, currentQ - 1))}
                disabled={currentQ === 0}
              >
                <ArrowLeft className="w-4 h-4" /> Previous
              </Button>
              <div className="flex items-center gap-2">
                {activeExam.questions.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setCurrentQ(i)}
                    className={cn(
                      'w-8 h-8 rounded-lg text-xs font-medium transition-all',
                      i === currentQ ? 'bg-primary-600 text-white' :
                      answers[activeExam.questions[i].id] ? 'bg-success-100 text-success-700 dark:bg-success-900/30 dark:text-success-300' :
                      'bg-gray-100 dark:bg-gray-700 text-gray-500'
                    )}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
              {currentQ === totalQuestions - 1 ? (
                <Button variant="success" onClick={() => setConfirmSubmit(true)}>
                  <Flag className="w-4 h-4" /> Submit
                </Button>
              ) : (
                <Button onClick={() => setCurrentQ(Math.min(totalQuestions - 1, currentQ + 1))}>
                  Next <ArrowRight className="w-4 h-4" />
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <Modal open={confirmSubmit} onClose={() => setConfirmSubmit(false)} title="Submit Exam?" size="sm">
          <p className="text-sm text-gray-600 dark:text-gray-300">
            You have answered {Object.keys(answers).length} out of {totalQuestions} questions.
            {Object.keys(answers).length < totalQuestions && ' Unanswered questions will be marked as wrong.'}
            Are you sure you want to submit?
          </p>
          <div className="flex justify-end gap-3 mt-6">
            <Button variant="outline" onClick={() => setConfirmSubmit(false)}>Cancel</Button>
            <Button variant="success" onClick={submitExam}>Yes, Submit</Button>
          </div>
        </Modal>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <PageHeader title="Online Tests" description="Take online examinations and view your scores" />
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-48" />)}
        </div>
      ) : exams.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <ClipboardList className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No exams available at the moment</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {exams.map((exam) => (
            <Card key={exam.id} className="hover:shadow-md transition-shadow">
              <CardContent>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-lg bg-warning-100 dark:bg-warning-900/30 flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-warning-600 dark:text-warning-400" />
                  </div>
                  <Badge variant={exam.is_published ? 'success' : 'default'}>
                    {exam.is_published ? 'Available' : 'Draft'}
                  </Badge>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{exam.title}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">{exam.description}</p>
                <div className="flex items-center gap-3 mt-4 text-xs text-gray-500 dark:text-gray-400">
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {exam.duration_minutes}m</span>
                  <span className="flex items-center gap-1"><Award className="w-3 h-3" /> {exam.total_marks} marks</span>
                  <span>Pass: {exam.passing_marks}</span>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <span className="text-xs text-gray-500">{formatDateTime(exam.start_time)}</span>
                  <Button size="sm" onClick={() => startExam(exam)}>
                    <Play className="w-3.5 h-3.5" /> Start Test
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
