import { useEffect, useState } from 'react';
import { BookOpen, Award, FileText } from 'lucide-react';
import { supabase, type Subject } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardContent } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';

export function StudentSubjectsPage() {
  const { student } = useAuth();
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchSubjects(); }, [student]);

  const fetchSubjects = async () => {
    if (!student) return;
    const { data } = await supabase.from('subjects').select('*, course:courses(*)').eq('semester_id', student.semester_id).order('name');
    setSubjects(data || []);
    setLoading(false);
  };

  if (loading) {
    return <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">{[...Array(6)].map((_, i) => <div key={i} className="skeleton h-48" />)}</div>;
  }

  return (
    <div className="animate-fade-in">
      <PageHeader title="My Subjects" description={`Subjects for Semester ${student?.current_semester || 1}`} />
      {subjects.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-gray-500">No subjects found for your semester</CardContent></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjects.map((s) => (
            <Card key={s.id} className="hover:shadow-md transition-shadow">
              <CardContent>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-12 h-12 rounded-lg bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <Badge variant="primary">{s.code}</Badge>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white">{s.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-1 line-clamp-2">{s.description || 'No description available'}</p>
                <div className="flex items-center gap-4 mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <div className="flex items-center gap-1.5 text-sm text-gray-500">
                    <Award className="w-4 h-4" /> {s.credits} credits
                  </div>
                  <div className="flex items-center gap-1.5 text-sm text-gray-500">
                    <FileText className="w-4 h-4" /> {s.total_marks} marks
                  </div>
                </div>
                <div className="mt-2 text-xs text-gray-400">Passing: {s.passing_marks} marks</div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
