import { useEffect, useState } from 'react';
import { Award, Download, TrendingUp, BookOpen, Target } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../context/AuthContext';
import { PageHeader } from '../../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardContent } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { StatCard } from '../../components/ui/StatCard';
import { BarChart, ProgressRing } from '../../components/charts/Charts';
import { useToast } from '../../components/ui/Toast';
import { calculateGrade, calculateSGPA, calculateGradePoint, exportToCSV, formatDateTime } from '../../lib/utils';

export function StudentResultsPage() {
  const { student } = useAuth();
  const { toast } = useToast();
  const [marks, setMarks] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { fetchResults(); }, [student]);

  const fetchResults = async () => {
    if (!student) return;
    setLoading(true);
    const [{ data: marksData }, { data: resultsData }] = await Promise.all([
      supabase.from('marks').select('*, subject:subjects(*), exam:exams(*), semester:semesters(*)').eq('student_id', student.id).order('created_at', { ascending: false }),
      supabase.from('results').select('*, exam:exams(*)').eq('student_id', student.id).eq('is_published', true).order('created_at', { ascending: false }),
    ]);
    setMarks(marksData || []);
    setResults(resultsData || []);
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => <div key={i} className="skeleton h-32" />)}
        </div>
        <div className="skeleton h-96" />
      </div>
    );
  }

  const totalMarks = marks.reduce((sum, m) => sum + m.marks_obtained, 0);
  const totalPossible = marks.reduce((sum, m) => sum + m.total_marks, 0);
  const overallPercentage = totalPossible > 0 ? Math.round((totalMarks / totalPossible) * 100) : 0;
  const overallGrade = calculateGrade(overallPercentage);

  const marksWithCredits = marks.map((m) => ({
    marks_obtained: m.marks_obtained,
    total_marks: m.total_marks,
    credits: m.subject?.credits || 4,
  }));
  const sgpa = calculateSGPA(marksWithCredits);
  const cgpa = sgpa;

  const subjectChart = marks.map((m) => ({
    label: m.subject?.name?.split(' ')[0] || 'Sub',
    value: Math.round((m.marks_obtained / m.total_marks) * 100),
  }));

  const handleExport = () => {
    const headers = ['Subject', 'Exam', 'Marks Obtained', 'Total Marks', 'Percentage', 'Grade'];
    const rows = marks.map((m) => [
      m.subject?.name || '',
      m.exam?.title || '',
      m.marks_obtained,
      m.total_marks,
      ((m.marks_obtained / m.total_marks) * 100).toFixed(2),
      m.grade || calculateGrade((m.marks_obtained / m.total_marks) * 100),
    ]);
    exportToCSV('grade_card.csv', headers, rows);
    toast('Grade card exported', 'success');
  };

  return (
    <div className="animate-fade-in space-y-6">
      <PageHeader
        title="My Results"
        description="View your examination results and grade card"
        actions={<Button variant="outline" onClick={handleExport}><Download className="w-4 h-4" /> Download Grade Card</Button>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Overall Percentage" value={`${overallPercentage}%`} icon={<Target className="w-6 h-6" />} color="primary" />
        <StatCard title="Overall Grade" value={overallGrade} icon={<Award className="w-6 h-6" />} color="success" />
        <StatCard title="SGPA" value={sgpa.toFixed(2)} icon={<TrendingUp className="w-6 h-6" />} color="warning" />
        <StatCard title="CGPA" value={cgpa.toFixed(2)} icon={<BookOpen className="w-6 h-6" />} color="info" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Subject-wise Performance</CardTitle></CardHeader>
          <CardContent>
            {subjectChart.length > 0 ? (
              <BarChart data={subjectChart} height={240} />
            ) : (
              <div className="py-12 text-center text-gray-500">No results yet</div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Overall Score</CardTitle></CardHeader>
          <CardContent className="flex items-center justify-center">
            <ProgressRing value={overallPercentage} size={160} thickness={14} color="#3b82f6" label="Score" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>Grade Card</CardTitle></CardHeader>
        <CardContent className="p-0">
          {marks.length === 0 ? (
            <div className="py-12 text-center text-gray-500">No results published yet</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700">
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Subject</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Exam</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Marks</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Percentage</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Grade</th>
                    <th className="px-6 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Grade Point</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 dark:divide-gray-700/50">
                  {marks.map((m) => {
                    const pct = (m.marks_obtained / m.total_marks) * 100;
                    const grade = m.grade || calculateGrade(pct);
                    const gp = calculateGradePoint(pct);
                    return (
                      <tr key={m.id} className="hover:bg-gray-50 dark:hover:bg-gray-700/30">
                        <td className="px-6 py-3.5">
                          <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-white">{m.subject?.name}</p>
                            <p className="text-xs text-gray-500">{m.subject?.code}</p>
                          </div>
                        </td>
                        <td className="px-6 py-3.5 text-sm text-gray-500">{m.exam?.title || '-'}</td>
                        <td className="px-6 py-3.5 text-sm font-medium">{m.marks_obtained}/{m.total_marks}</td>
                        <td className="px-6 py-3.5"><Badge variant={pct >= 40 ? 'success' : 'error'}>{pct.toFixed(1)}%</Badge></td>
                        <td className="px-6 py-3.5"><Badge variant={grade === 'F' ? 'error' : 'primary'}>{grade}</Badge></td>
                        <td className="px-6 py-3.5 text-sm font-medium">{gp}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      {results.length > 0 && (
        <Card>
          <CardHeader><CardTitle>Online Test Results</CardTitle></CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-gray-100 dark:divide-gray-700/50">
              {results.map((r) => (
                <div key={r.id} className="flex items-center gap-4 px-6 py-4">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${r.is_passed ? 'bg-success-100 dark:bg-success-900/30' : 'bg-error-100 dark:bg-error-900/30'}`}>
                    <Award className={`w-6 h-6 ${r.is_passed ? 'text-success-600' : 'text-error-600'}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">{r.exam?.title}</p>
                    <p className="text-xs text-gray-500">{formatDateTime(r.published_at || r.created_at)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-gray-900 dark:text-white">{r.percentage}%</p>
                    <Badge variant={r.is_passed ? 'success' : 'error'}>Grade: {r.grade}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
