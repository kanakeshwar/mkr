import {
  LayoutDashboard, Users, GraduationCap, Building2, BookOpen, CalendarDays,
  FileText, ClipboardList, BarChart3, Settings, ClipboardCheck, Award,
  Bell, User, FileEdit, CheckSquare, Upload, FileBarChart, CalendarClock,
  type LucideIcon,
} from 'lucide-react';
import type { UserRole } from '../../lib/supabase';

export type NavItem = {
  id: string;
  label: string;
  icon: LucideIcon;
  path: string;
};

export type NavSection = {
  id: string;
  title: string;
  items: NavItem[];
};

export const adminNav: NavSection[] = [
  {
    id: 'overview',
    title: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/admin/dashboard' },
    ],
  },
  {
    id: 'management',
    title: 'Management',
    items: [
      { id: 'students', label: 'Students', icon: Users, path: '/admin/students' },
      { id: 'teachers', label: 'Teachers', icon: GraduationCap, path: '/admin/teachers' },
      { id: 'departments', label: 'Departments', icon: Building2, path: '/admin/departments' },
      { id: 'courses', label: 'Courses', icon: BookOpen, path: '/admin/courses' },
      { id: 'semesters', label: 'Semesters', icon: CalendarDays, path: '/admin/semesters' },
      { id: 'subjects', label: 'Subjects', icon: FileText, path: '/admin/subjects' },
    ],
  },
  {
    id: 'academic',
    title: 'Academic',
    items: [
      { id: 'exams', label: 'Exams', icon: ClipboardList, path: '/admin/exams' },
      { id: 'questions', label: 'Question Bank', icon: FileEdit, path: '/admin/questions' },
      { id: 'results', label: 'Results', icon: Award, path: '/admin/results' },
      { id: 'reports', label: 'Reports', icon: BarChart3, path: '/admin/reports' },
    ],
  },
  {
    id: 'system',
    title: 'System',
    items: [
      { id: 'settings', label: 'Settings', icon: Settings, path: '/admin/settings' },
    ],
  },
];

export const teacherNav: NavSection[] = [
  {
    id: 'overview',
    title: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/teacher/dashboard' },
    ],
  },
  {
    id: 'academic',
    title: 'Academic',
    items: [
      { id: 'students', label: 'Student List', icon: Users, path: '/teacher/students' },
      { id: 'attendance', label: 'Attendance', icon: CheckSquare, path: '/teacher/attendance' },
      { id: 'exams', label: 'Exams', icon: ClipboardList, path: '/teacher/exams' },
      { id: 'questions', label: 'Question Bank', icon: FileEdit, path: '/teacher/questions' },
      { id: 'marks', label: 'Marks Entry', icon: Upload, path: '/teacher/marks' },
      { id: 'assignments', label: 'Assignments', icon: ClipboardCheck, path: '/teacher/assignments' },
    ],
  },
  {
    id: 'analysis',
    title: 'Analysis',
    items: [
      { id: 'results', label: 'Results', icon: Award, path: '/teacher/results' },
      { id: 'analytics', label: 'Performance', icon: FileBarChart, path: '/teacher/analytics' },
    ],
  },
  {
    id: 'personal',
    title: 'Personal',
    items: [
      { id: 'profile', label: 'Profile', icon: User, path: '/teacher/profile' },
    ],
  },
];

export const studentNav: NavSection[] = [
  {
    id: 'overview',
    title: 'Overview',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/student/dashboard' },
    ],
  },
  {
    id: 'academic',
    title: 'Academic',
    items: [
      { id: 'subjects', label: 'Subjects', icon: BookOpen, path: '/student/subjects' },
      { id: 'attendance', label: 'Attendance', icon: CheckSquare, path: '/student/attendance' },
      { id: 'exams', label: 'Exam Schedule', icon: CalendarClock, path: '/student/exams' },
      { id: 'tests', label: 'Online Tests', icon: ClipboardList, path: '/student/tests' },
      { id: 'assignments', label: 'Assignments', icon: ClipboardCheck, path: '/student/assignments' },
    ],
  },
  {
    id: 'results',
    title: 'Results',
    items: [
      { id: 'results', label: 'Results', icon: Award, path: '/student/results' },
    ],
  },
  {
    id: 'personal',
    title: 'Personal',
    items: [
      { id: 'notifications', label: 'Notifications', icon: Bell, path: '/student/notifications' },
      { id: 'profile', label: 'Profile', icon: User, path: '/student/profile' },
    ],
  },
];

export function getNavForRole(role: UserRole): NavSection[] {
  switch (role) {
    case 'admin': return adminNav;
    case 'teacher': return teacherNav;
    case 'student': return studentNav;
  }
}
