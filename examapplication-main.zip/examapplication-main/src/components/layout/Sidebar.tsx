import { GraduationCap, X, ChevronLeft } from 'lucide-react';
import { cn } from '../../lib/utils';
import { getNavForRole } from './navigation';
import { useAuth } from '../../context/AuthContext';

type SidebarProps = {
  currentPath: string;
  onNavigate: (path: string) => void;
  open: boolean;
  onClose: () => void;
};

export function Sidebar({ currentPath, onNavigate, open, onClose }: SidebarProps) {
  const { profile } = useAuth();
  const nav = profile ? getNavForRole(profile.role) : [];

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/50 z-30 lg:hidden" onClick={onClose} />
      )}
      <aside
        className={cn(
          'fixed lg:sticky top-0 left-0 h-screen w-64 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-800 z-40 transition-transform duration-300 flex flex-col',
          open ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        <div className="h-16 flex items-center justify-between px-5 border-b border-gray-200 dark:border-gray-800 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg shadow-primary-600/20">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-gray-900 dark:text-white leading-tight">College EMS</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Examination System</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
          {nav.map((section) => (
            <div key={section.id}>
              <p className="px-3 mb-2 text-xs font-semibold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
                {section.title}
              </p>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const active = currentPath === item.path;
                  return (
                    <button
                      key={item.id}
                      onClick={() => onNavigate(item.path)}
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 group',
                        active
                          ? 'bg-primary-50 dark:bg-primary-900/20 text-primary-700 dark:text-primary-300'
                          : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200'
                      )}
                    >
                      <Icon className={cn('w-[18px] h-[18px] flex-shrink-0', active && 'text-primary-600 dark:text-primary-400')} />
                      <span className="flex-1 text-left">{item.label}</span>
                      {active && <div className="w-1.5 h-1.5 rounded-full bg-primary-500" />}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="p-4 border-t border-gray-200 dark:border-gray-800 flex-shrink-0">
          <div className="rounded-lg bg-gradient-to-br from-primary-50 to-accent-50 dark:from-primary-900/20 dark:to-accent-900/20 p-3.5 border border-primary-100 dark:border-primary-800/30">
            <p className="text-xs font-semibold text-gray-700 dark:text-gray-300">Need Help?</p>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">Check the documentation</p>
            <button className="mt-2 text-xs font-medium text-primary-600 dark:text-primary-400 hover:underline flex items-center gap-1">
              View Docs <ChevronLeft className="w-3 h-3 rotate-180" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
