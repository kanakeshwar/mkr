import { type ReactNode } from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '../../lib/utils';

type StatCardProps = {
  title: string;
  value: string | number;
  icon: ReactNode;
  trend?: { value: number; label: string };
  color?: 'primary' | 'success' | 'warning' | 'error' | 'info' | 'accent';
  onClick?: () => void;
};

const colors = {
  primary: { bg: 'bg-primary-50 dark:bg-primary-900/20', icon: 'bg-primary-500', text: 'text-primary-600 dark:text-primary-400' },
  success: { bg: 'bg-success-50 dark:bg-success-900/20', icon: 'bg-success-500', text: 'text-success-600 dark:text-success-400' },
  warning: { bg: 'bg-warning-50 dark:bg-warning-900/20', icon: 'bg-warning-500', text: 'text-warning-600 dark:text-warning-400' },
  error: { bg: 'bg-error-50 dark:bg-error-900/20', icon: 'bg-error-500', text: 'text-error-600 dark:text-error-400' },
  info: { bg: 'bg-accent-50 dark:bg-accent-900/20', icon: 'bg-accent-500', text: 'text-accent-600 dark:text-accent-400' },
  accent: { bg: 'bg-accent-50 dark:bg-accent-900/20', icon: 'bg-accent-500', text: 'text-accent-600 dark:text-accent-400' },
};

export function StatCard({ title, value, icon, trend, color = 'primary', onClick }: StatCardProps) {
  const c = colors[color];
  return (
    <div
      onClick={onClick}
      className={cn(
        'card p-5 transition-all duration-200',
        onClick && 'cursor-pointer hover:shadow-md hover:-translate-y-0.5'
      )}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-2">{value}</p>
          {trend && (
            <div className="flex items-center gap-1.5 mt-2">
              {trend.value >= 0 ? (
                <TrendingUp className="w-4 h-4 text-success-500" />
              ) : (
                <TrendingDown className="w-4 h-4 text-error-500" />
              )}
              <span className={cn('text-xs font-medium', trend.value >= 0 ? 'text-success-600 dark:text-success-400' : 'text-error-600 dark:text-error-400')}>
                {Math.abs(trend.value)}%
              </span>
              <span className="text-xs text-gray-500 dark:text-gray-400">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={cn('w-12 h-12 rounded-xl flex items-center justify-center text-white shadow-lg flex-shrink-0', c.icon)}>
          {icon}
        </div>
      </div>
    </div>
  );
}
