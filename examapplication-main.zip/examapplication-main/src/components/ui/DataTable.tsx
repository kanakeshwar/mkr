import { type ReactNode, useState, useMemo } from 'react';
import { Search, Download, Plus, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { Table } from './Table';
import { Pagination } from './Pagination';
import { Button } from './Button';
import { exportToCSV } from '../../lib/utils';

type Column<T> = {
  key: string;
  header: string;
  render?: (item: T) => ReactNode;
  sortable?: boolean;
  sortValue?: (item: T) => string | number;
  className?: string;
};

type DataTableProps<T> = {
  columns: Column<T>[];
  data: T[];
  loading?: boolean;
  onAdd?: () => void;
  addLabel?: string;
  searchKeys?: (keyof T)[];
  searchPlaceholder?: string;
  pageSize?: number;
  emptyMessage?: string;
  onRowClick?: (item: T) => void;
  exportFilename?: string;
  filters?: ReactNode;
};

export function DataTable<T extends { id: string }>({
  columns,
  data,
  loading,
  onAdd,
  addLabel = 'Add New',
  searchKeys = [],
  searchPlaceholder = 'Search...',
  pageSize = 10,
  emptyMessage = 'No data found',
  onRowClick,
  exportFilename = 'export',
  filters,
}: DataTableProps<T>) {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [sortKey, setSortKey] = useState<string | null>(null);
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const filtered = useMemo(() => {
    if (!search || searchKeys.length === 0) return data;
    const lower = search.toLowerCase();
    return data.filter((item) =>
      searchKeys.some((key) => String(item[key] || '').toLowerCase().includes(lower))
    );
  }, [data, search, searchKeys]);

  const sorted = useMemo(() => {
    if (!sortKey) return filtered;
    const col = columns.find((c) => c.key === sortKey);
    if (!col?.sortValue) return filtered;
    return [...filtered].sort((a, b) => {
      const av = col.sortValue!(a);
      const bv = col.sortValue!(b);
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filtered, sortKey, sortDir, columns]);

  const totalPages = Math.ceil(sorted.length / pageSize);
  const paged = sorted.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (key: string) => {
    if (sortKey === key) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const handleExport = () => {
    const headers = columns.map((c) => c.header);
    const rows = sorted.map((item) =>
      columns.map((c) => {
        const val = c.sortValue ? c.sortValue(item) : (item as Record<string, unknown>)[c.key];
        return val as string | number;
      })
    );
    exportToCSV(`${exportFilename}.csv`, headers, rows);
  };

  const tableColumns = columns.map((c) => ({
    ...c,
    header: c.sortable ? (
      <button
        onClick={() => handleSort(c.key)}
        className="flex items-center gap-1 hover:text-gray-700 dark:hover:text-gray-200"
      >
        {c.header}
        {sortKey === c.key ? (
          sortDir === 'asc' ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />
        ) : (
          <ArrowUpDown className="w-3 h-3 opacity-40" />
        )}
      </button>
    ) : c.header,
  }));

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        {searchKeys.length > 0 && (
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder={searchPlaceholder}
              className="input pl-10"
            />
          </div>
        )}
        <div className="flex items-center gap-2">
          {filters}
          <Button variant="outline" size="md" onClick={handleExport} disabled={data.length === 0}>
            <Download className="w-4 h-4" /> Export
          </Button>
          {onAdd && (
            <Button onClick={onAdd}>
              <Plus className="w-4 h-4" /> {addLabel}
            </Button>
          )}
        </div>
      </div>

      <div className="card overflow-hidden">
        <Table columns={tableColumns} data={paged} loading={loading} emptyMessage={emptyMessage} onRowClick={onRowClick} />
      </div>

      {totalPages > 1 && <Pagination page={page} totalPages={totalPages} onPageChange={setPage} />}
    </div>
  );
}
