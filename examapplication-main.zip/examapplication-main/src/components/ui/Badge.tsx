import { type ReactNode } from 'react';
import { cn } from '../../lib/utils';

type BadgeProps = {
  children: ReactNode;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'error' | 'info';
  className?: string;
};

const variants = {
  default: 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-300',
  primary: 'bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-300',
  success: 'bg-success-100 text-success-700 dark:bg-success-900/30 dark:text-success-300',
  warning: 'bg-warning-100 text-warning-700 dark:bg-warning-900/30 dark:text-warning-300',
  error: 'bg-error-100 text-error-700 dark:bg-error-900/30 dark:text-error-300',
  info: 'bg-accent-100 text-accent-700 dark:bg-accent-900/30 dark:text-accent-300',
};

export function Badge({ children, variant = 'default', className }: BadgeProps) {
  return <span className={cn('badge', variants[variant], className)}>{children}</span>;
}
