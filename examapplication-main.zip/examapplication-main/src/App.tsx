import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { ToastProvider } from './components/ui/Toast';
import { Layout } from './components/layout/Layout';
import { LoginPage } from './pages/auth/LoginPage';
import { SignupPage } from './pages/auth/SignupPage';

// Admin pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { StudentsPage } from './pages/admin/StudentsPage';
import { TeachersPage } from './pages/admin/TeachersPage';
import { DepartmentsPage } from './pages/admin/DepartmentsPage';
import { CoursesPage } from './pages/admin/CoursesPage';
import { SemestersPage } from './pages/admin/SemestersPage';
import { SubjectsPage } from './pages/admin/SubjectsPage';
import { ExamsPage } from './pages/admin/ExamsPage';
import { QuestionsPage } from './pages/admin/QuestionsPage';
import { ResultsPage } from './pages/admin/ResultsPage';
import { ReportsPage } from './pages/admin/ReportsPage';
import { SettingsPage } from './pages/admin/SettingsPage';

// Teacher pages
import { TeacherDashboard } from './pages/teacher/TeacherDashboard';
import { TeacherStudentsPage } from './pages/teacher/TeacherStudentsPage';
import { AttendancePage } from './pages/teacher/AttendancePage';
import { MarksEntryPage } from './pages/teacher/MarksEntryPage';
import { AssignmentsPage } from './pages/shared/AssignmentsPage';

// Student pages
import { StudentDashboard } from './pages/student/StudentDashboard';
import { StudentSubjectsPage } from './pages/student/StudentSubjectsPage';
import { StudentAttendancePage } from './pages/student/StudentAttendancePage';
import { StudentExamSchedulePage } from './pages/student/StudentExamSchedulePage';
import { OnlineTestPage } from './pages/student/OnlineTestPage';
import { StudentResultsPage } from './pages/student/StudentResultsPage';
import { StudentNotificationsPage } from './pages/student/StudentNotificationsPage';

// Shared pages
import { ProfilePage } from './pages/shared/ProfilePage';

function AppContent() {
  const { session, profile, loading } = useAuth();
  const [route, setRoute] = useState(window.location.pathname);

  useEffect(() => {
    const handlePopState = () => setRoute(window.location.pathname);
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setRoute(path);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-950">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center animate-pulse">
            <svg className="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l9-5-9-5-9 5 9 5z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-6.998 12.078 12.078 0 01.665-6.479L12 14z" />
            </svg>
          </div>
          <p className="text-sm text-gray-500">Loading College EMS...</p>
        </div>
      </div>
    );
  }

  if (!session || !profile) {
    if (route === '/signup') {
      return <SignupPage onNavigate={navigate} />;
    }
    return <LoginPage onNavigate={navigate} />;
  }

  const role = profile.role;

  const renderPage = () => {
    // Admin routes
    if (role === 'admin') {
      switch (route) {
        case '/admin/dashboard': return <AdminDashboard />;
        case '/admin/students': return <StudentsPage />;
        case '/admin/teachers': return <TeachersPage />;
        case '/admin/departments': return <DepartmentsPage />;
        case '/admin/courses': return <CoursesPage />;
        case '/admin/semesters': return <SemestersPage />;
        case '/admin/subjects': return <SubjectsPage />;
        case '/admin/exams': return <ExamsPage />;
        case '/admin/questions': return <QuestionsPage />;
        case '/admin/results': return <ResultsPage />;
        case '/admin/reports': return <ReportsPage />;
        case '/admin/settings': return <SettingsPage />;
        case '/admin/profile': return <ProfilePage />;
        default: return <AdminDashboard />;
      }
    }

    // Teacher routes
    if (role === 'teacher') {
      switch (route) {
        case '/teacher/dashboard': return <TeacherDashboard />;
        case '/teacher/students': return <TeacherStudentsPage />;
        case '/teacher/attendance': return <AttendancePage />;
        case '/teacher/exams': return <ExamsPage />;
        case '/teacher/questions': return <QuestionsPage />;
        case '/teacher/marks': return <MarksEntryPage />;
        case '/teacher/assignments': return <AssignmentsPage />;
        case '/teacher/results': return <ResultsPage />;
        case '/teacher/analytics': return <ReportsPage />;
        case '/teacher/profile': return <ProfilePage />;
        default: return <TeacherDashboard />;
      }
    }

    // Student routes
    if (role === 'student') {
      switch (route) {
        case '/student/dashboard': return <StudentDashboard />;
        case '/student/subjects': return <StudentSubjectsPage />;
        case '/student/attendance': return <StudentAttendancePage />;
        case '/student/exams': return <StudentExamSchedulePage />;
        case '/student/tests': return <OnlineTestPage />;
        case '/student/assignments': return <AssignmentsPage />;
        case '/student/results': return <StudentResultsPage />;
        case '/student/notifications': return <StudentNotificationsPage />;
        case '/student/profile': return <ProfilePage />;
        default: return <StudentDashboard />;
      }
    }

    return <AdminDashboard />;
  };

  return (
    <Layout currentPath={route} onNavigate={navigate}>
      {renderPage()}
    </Layout>
  );
}

function App() {
  return (
    <ThemeProvider>
      <ToastProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </ToastProvider>
    </ThemeProvider>
  );
}

export default App;
