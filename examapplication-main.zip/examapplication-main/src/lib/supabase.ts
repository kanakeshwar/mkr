import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type UserRole = 'admin' | 'teacher' | 'student';

export type Profile = {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  phone?: string | null;
  avatar_url?: string | null;
  address?: string | null;
  date_of_birth?: string | null;
  gender?: 'male' | 'female' | 'other' | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type Department = {
  id: string;
  name: string;
  code: string;
  description?: string | null;
  head_of_department?: string | null;
  established_year?: number | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type Course = {
  id: string;
  name: string;
  code: string;
  description?: string | null;
  department_id?: string | null;
  duration_years: number;
  total_semesters: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  department?: Department | null;
};

export type Semester = {
  id: string;
  name: string;
  semester_number: number;
  course_id: string;
  start_date?: string | null;
  end_date?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
};

export type Subject = {
  id: string;
  name: string;
  code: string;
  description?: string | null;
  course_id?: string | null;
  semester_id?: string | null;
  credits: number;
  total_marks: number;
  passing_marks: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  course?: Course | null;
  semester?: Semester | null;
};

export type Teacher = {
  id: string;
  profile_id: string;
  employee_id: string;
  department_id?: string | null;
  designation: string;
  qualification?: string | null;
  specialization?: string | null;
  joining_date: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  profile?: Profile | null;
  department?: Department | null;
};

export type Student = {
  id: string;
  profile_id: string;
  roll_number: string;
  enrollment_number?: string | null;
  department_id?: string | null;
  course_id?: string | null;
  semester_id?: string | null;
  admission_date: string;
  current_semester: number;
  guardian_name?: string | null;
  guardian_phone?: string | null;
  blood_group?: string | null;
  address?: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  profile?: Profile | null;
  department?: Department | null;
  course?: Course | null;
  semester?: Semester | null;
};

export type Exam = {
  id: string;
  title: string;
  description?: string | null;
  subject_id: string;
  course_id?: string | null;
  semester_id?: string | null;
  exam_type: 'mcq_test' | 'descriptive' | 'mixed';
  total_marks: number;
  passing_marks: number;
  duration_minutes: number;
  start_time?: string | null;
  end_time?: string | null;
  negative_marking: number;
  randomize_questions: boolean;
  auto_submit: boolean;
  auto_evaluate: boolean;
  is_published: boolean;
  is_active: boolean;
  created_by?: string | null;
  created_at: string;
  updated_at: string;
  subject?: Subject | null;
  course?: Course | null;
  semester?: Semester | null;
};

export type Question = {
  id: string;
  subject_id: string;
  question_text: string;
  question_type: 'mcq' | 'descriptive' | 'true_false';
  difficulty: 'easy' | 'medium' | 'hard';
  marks: number;
  explanation?: string | null;
  is_active: boolean;
  created_by?: string | null;
  created_at: string;
  updated_at: string;
  subject?: Subject | null;
  options?: Option[];
};

export type Option = {
  id: string;
  question_id: string;
  option_text: string;
  is_correct: boolean;
  option_order: number;
  created_at: string;
};

export type ExamQuestion = {
  id: string;
  exam_id: string;
  question_id: string;
  question_order: number;
  marks: number;
  question?: Question;
};

export type StudentAnswer = {
  id: string;
  exam_id: string;
  question_id: string;
  student_id: string;
  selected_option_id?: string | null;
  answer_text?: string | null;
  is_correct?: boolean | null;
  marks_awarded: number;
  evaluated_at?: string | null;
  submitted_at: string;
};

export type Result = {
  id: string;
  exam_id: string;
  student_id: string;
  total_marks_obtained: number;
  total_marks_possible: number;
  percentage: number;
  grade?: string | null;
  rank?: number | null;
  is_passed: boolean;
  is_published: boolean;
  evaluated_at?: string | null;
  published_at?: string | null;
  created_at: string;
  updated_at: string;
  exam?: Exam;
  student?: Student;
};

export type Mark = {
  id: string;
  student_id: string;
  subject_id: string;
  exam_id?: string | null;
  semester_id?: string | null;
  marks_obtained: number;
  total_marks: number;
  grade?: string | null;
  is_published: boolean;
  entered_by?: string | null;
  created_at: string;
  updated_at: string;
  student?: Student;
  subject?: Subject;
  exam?: Exam;
  semester?: Semester;
};

export type Attendance = {
  id: string;
  student_id: string;
  subject_id?: string | null;
  date: string;
  status: 'present' | 'absent' | 'late';
  remarks?: string | null;
  marked_by?: string | null;
  created_at: string;
  student?: Student;
  subject?: Subject | null;
};

export type Assignment = {
  id: string;
  title: string;
  description?: string | null;
  subject_id?: string | null;
  course_id?: string | null;
  semester_id?: string | null;
  file_url?: string | null;
  file_name?: string | null;
  total_marks: number;
  due_date?: string | null;
  is_published: boolean;
  created_by?: string | null;
  created_at: string;
  updated_at: string;
  subject?: Subject | null;
};

export type AssignmentSubmission = {
  id: string;
  assignment_id: string;
  student_id: string;
  file_url?: string | null;
  file_name?: string | null;
  submission_text?: string | null;
  marks_obtained?: number | null;
  feedback?: string | null;
  is_graded: boolean;
  graded_by?: string | null;
  submitted_at: string;
  graded_at?: string | null;
  assignment?: Assignment;
  student?: Student;
};

export type Notification = {
  id: string;
  user_id?: string | null;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'exam' | 'result';
  is_read: boolean;
  link?: string | null;
  created_at: string;
};

export type TeacherSubject = {
  id: string;
  teacher_id: string;
  subject_id: string;
  assigned_at: string;
  subject?: Subject;
  teacher?: Teacher;
};
