/*
# Core Schema - College Examination Management System

## Overview
Creates the foundational tables for the college examination management system:
user profiles with roles, departments, courses, semesters, subjects, students,
and teachers. Includes a helper function for role-based access control.

## New Tables
1. `profiles` - Extends auth.users with role (admin/teacher/student), name, avatar
2. `departments` - Academic departments (e.g. Computer Science, Mathematics)
3. `courses` - Degree programs (e.g. B.Tech, M.Sc) linked to a department
4. `semesters` - Semester definitions (1-8) linked to a course
5. `subjects` - Subjects linked to a course + semester
6. `students` - Student records linked to profile, department, course, semester
7. `teachers` - Teacher records linked to profile and department
8. `teacher_subjects` - Many-to-many mapping of teachers to subjects

## Security
- RLS enabled on all tables
- Role-based policies using `user_role()` helper function
- Admins have full CRUD access to all tables
- Teachers can read relevant academic data and manage their assigned subjects
- Students can read their own records and related academic data
- All tables allow authenticated users to read reference data (departments, courses, etc.)

## Notes
1. `user_role()` is a SECURITY DEFINER function that returns the current user's role
2. Profile records are auto-created via trigger when auth.users records are inserted
3. Owner columns default to `auth.uid()` where applicable
*/

-- Step 1: Create profiles table WITHOUT policies first
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  full_name text not null,
  role text not null check (role in ('admin', 'teacher', 'student')) default 'student',
  phone text,
  avatar_url text,
  address text,
  date_of_birth date,
  gender text check (gender in ('male', 'female', 'other')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Step 2: Create the user_role() helper function (profiles table now exists)
create or replace function public.user_role()
returns text
language sql
security definer
stable
as $$
  select role from public.profiles where id = auth.uid();
$$;

-- Step 3: Enable RLS and add policies on profiles
alter table public.profiles enable row level security;

drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
  for select to authenticated
  using (auth.uid() = id or public.user_role() = 'admin' or public.user_role() = 'teacher');

drop policy if exists "profiles_insert_self_or_admin" on public.profiles;
create policy "profiles_insert_self_or_admin" on public.profiles
  for insert to authenticated
  with check (auth.uid() = id or public.user_role() = 'admin');

drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin" on public.profiles
  for update to authenticated
  using (auth.uid() = id or public.user_role() = 'admin')
  with check (auth.uid() = id or public.user_role() = 'admin');

drop policy if exists "profiles_delete_admin_only" on public.profiles;
create policy "profiles_delete_admin_only" on public.profiles
  for delete to authenticated
  using (public.user_role() = 'admin');

-- Departments
create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  code text not null unique,
  description text,
  head_of_department text,
  established_year int,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.departments enable row level security;

drop policy if exists "departments_select_all" on public.departments;
create policy "departments_select_all" on public.departments
  for select to authenticated using (true);

drop policy if exists "departments_modify_admin" on public.departments;
create policy "departments_modify_admin" on public.departments
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "departments_update_admin" on public.departments;
create policy "departments_update_admin" on public.departments
  for update to authenticated using (public.user_role() = 'admin') with check (public.user_role() = 'admin');

drop policy if exists "departments_delete_admin" on public.departments;
create policy "departments_delete_admin" on public.departments
  for delete to authenticated using (public.user_role() = 'admin');

-- Courses
create table if not exists public.courses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  description text,
  department_id uuid references public.departments(id) on delete set null,
  duration_years int not null default 4,
  total_semesters int not null default 8,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.courses enable row level security;

drop policy if exists "courses_select_all" on public.courses;
create policy "courses_select_all" on public.courses
  for select to authenticated using (true);

drop policy if exists "courses_insert_admin" on public.courses;
create policy "courses_insert_admin" on public.courses
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "courses_update_admin" on public.courses;
create policy "courses_update_admin" on public.courses
  for update to authenticated using (public.user_role() = 'admin') with check (public.user_role() = 'admin');

drop policy if exists "courses_delete_admin" on public.courses;
create policy "courses_delete_admin" on public.courses
  for delete to authenticated using (public.user_role() = 'admin');

-- Semesters
create table if not exists public.semesters (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  semester_number int not null check (semester_number between 1 and 12),
  course_id uuid references public.courses(id) on delete cascade,
  start_date date,
  end_date date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(course_id, semester_number)
);

alter table public.semesters enable row level security;

drop policy if exists "semesters_select_all" on public.semesters;
create policy "semesters_select_all" on public.semesters
  for select to authenticated using (true);

drop policy if exists "semesters_insert_admin" on public.semesters;
create policy "semesters_insert_admin" on public.semesters
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "semesters_update_admin" on public.semesters;
create policy "semesters_update_admin" on public.semesters
  for update to authenticated using (public.user_role() = 'admin') with check (public.user_role() = 'admin');

drop policy if exists "semesters_delete_admin" on public.semesters;
create policy "semesters_delete_admin" on public.semesters
  for delete to authenticated using (public.user_role() = 'admin');

-- Subjects
create table if not exists public.subjects (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  description text,
  course_id uuid references public.courses(id) on delete set null,
  semester_id uuid references public.semesters(id) on delete set null,
  credits int not null default 4,
  total_marks int not null default 100,
  passing_marks int not null default 40,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.subjects enable row level security;

drop policy if exists "subjects_select_all" on public.subjects;
create policy "subjects_select_all" on public.subjects
  for select to authenticated using (true);

drop policy if exists "subjects_insert_admin_teacher" on public.subjects;
create policy "subjects_insert_admin_teacher" on public.subjects
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "subjects_update_admin_teacher" on public.subjects;
create policy "subjects_update_admin_teacher" on public.subjects
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "subjects_delete_admin" on public.subjects;
create policy "subjects_delete_admin" on public.subjects
  for delete to authenticated using (public.user_role() = 'admin');

-- Teachers
create table if not exists public.teachers (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  employee_id text not null unique,
  department_id uuid references public.departments(id) on delete set null,
  designation text default 'Assistant Professor',
  qualification text,
  specialization text,
  joining_date date default current_date,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.teachers enable row level security;

drop policy if exists "teachers_select_all" on public.teachers;
create policy "teachers_select_all" on public.teachers
  for select to authenticated using (true);

drop policy if exists "teachers_insert_admin" on public.teachers;
create policy "teachers_insert_admin" on public.teachers
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "teachers_update_admin_self" on public.teachers;
create policy "teachers_update_admin_self" on public.teachers
  for update to authenticated
  using (public.user_role() = 'admin' or auth.uid() = profile_id)
  with check (public.user_role() = 'admin' or auth.uid() = profile_id);

drop policy if exists "teachers_delete_admin" on public.teachers;
create policy "teachers_delete_admin" on public.teachers
  for delete to authenticated using (public.user_role() = 'admin');

-- Teacher-Subject mapping
create table if not exists public.teacher_subjects (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.teachers(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  assigned_at timestamptz not null default now(),
  unique(teacher_id, subject_id)
);

alter table public.teacher_subjects enable row level security;

drop policy if exists "teacher_subjects_select_all" on public.teacher_subjects;
create policy "teacher_subjects_select_all" on public.teacher_subjects
  for select to authenticated using (true);

drop policy if exists "teacher_subjects_insert_admin" on public.teacher_subjects;
create policy "teacher_subjects_insert_admin" on public.teacher_subjects
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "teacher_subjects_update_admin" on public.teacher_subjects;
create policy "teacher_subjects_update_admin" on public.teacher_subjects
  for update to authenticated using (public.user_role() = 'admin') with check (public.user_role() = 'admin');

drop policy if exists "teacher_subjects_delete_admin" on public.teacher_subjects;
create policy "teacher_subjects_delete_admin" on public.teacher_subjects
  for delete to authenticated using (public.user_role() = 'admin');

-- Students
create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references public.profiles(id) on delete cascade,
  roll_number text not null unique,
  enrollment_number text unique,
  department_id uuid references public.departments(id) on delete set null,
  course_id uuid references public.courses(id) on delete set null,
  semester_id uuid references public.semesters(id) on delete set null,
  admission_date date default current_date,
  current_semester int not null default 1,
  guardian_name text,
  guardian_phone text,
  blood_group text,
  address text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.students enable row level security;

drop policy if exists "students_select_admin_teacher_self" on public.students;
create policy "students_select_admin_teacher_self" on public.students
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or auth.uid() = profile_id
  );

drop policy if exists "students_insert_admin" on public.students;
create policy "students_insert_admin" on public.students
  for insert to authenticated with check (public.user_role() = 'admin');

drop policy if exists "students_update_admin_self" on public.students;
create policy "students_update_admin_self" on public.students
  for update to authenticated
  using (public.user_role() = 'admin' or auth.uid() = profile_id)
  with check (public.user_role() = 'admin' or auth.uid() = profile_id);

drop policy if exists "students_delete_admin" on public.students;
create policy "students_delete_admin" on public.students
  for delete to authenticated using (public.user_role() = 'admin');

-- Trigger to auto-create profile when auth user is created
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
as $$
begin
  insert into public.profiles (id, email, full_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', 'New User'),
    coalesce(new.raw_user_meta_data->>'role', 'student')
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- Indexes for performance
create index if not exists idx_profiles_role on public.profiles(role);
create index if not exists idx_students_profile_id on public.students(profile_id);
create index if not exists idx_students_department_id on public.students(department_id);
create index if not exists idx_students_course_id on public.students(course_id);
create index if not exists idx_teachers_profile_id on public.teachers(profile_id);
create index if not exists idx_teachers_department_id on public.teachers(department_id);
create index if not exists idx_subjects_course_id on public.subjects(course_id);
create index if not exists idx_subjects_semester_id on public.subjects(semester_id);
create index if not exists idx_teacher_subjects_teacher_id on public.teacher_subjects(teacher_id);
create index if not exists idx_teacher_subjects_subject_id on public.teacher_subjects(subject_id);
