/*
# Seed Academic Data

## Overview
Inserts sample academic data for testing: departments, courses, semesters,
subjects, teacher users, student users, and sample exams/questions.

## Data Created
1. 4 Departments (CSE, ECE, ME, CE)
2. 2 Courses (B.Tech CSE, B.Tech ECE)
3. 8 Semesters (1-8 for B.Tech CSE)
4. 8 Subjects across semesters
5. 3 Teacher users with teacher records
6. 5 Student users with student records
7. Sample exam and questions with options

## Notes
1. All passwords are 'password123' (bcrypt hashed)
2. Teacher emails: teacher1@college.edu, teacher2@college.edu, teacher3@college.edu
3. Student emails: student1@college.edu through student5@college.edu
4. This data is for testing/demo purposes only
*/

-- Insert departments
INSERT INTO public.departments (name, code, description, head_of_department, established_year) VALUES
('Computer Science & Engineering', 'CSE', 'Department of Computer Science and Engineering', 'Dr. Rajesh Kumar', 1995),
('Electronics & Communication', 'ECE', 'Department of Electronics and Communication Engineering', 'Dr. Sunita Sharma', 1998),
('Mechanical Engineering', 'ME', 'Department of Mechanical Engineering', 'Dr. Amit Verma', 1990),
('Civil Engineering', 'CE', 'Department of Civil Engineering', 'Dr. Priya Singh', 1992)
ON CONFLICT (code) DO NOTHING;

-- Insert courses
INSERT INTO public.courses (name, code, description, department_id, duration_years, total_semesters) VALUES
('Bachelor of Technology - CSE', 'BTECH-CSE', '4-year B.Tech in Computer Science', (SELECT id FROM public.departments WHERE code='CSE'), 4, 8),
('Bachelor of Technology - ECE', 'BTECH-ECE', '4-year B.Tech in Electronics', (SELECT id FROM public.departments WHERE code='ECE'), 4, 8)
ON CONFLICT (code) DO NOTHING;

-- Insert semesters for B.Tech CSE
INSERT INTO public.semesters (name, semester_number, course_id, start_date, end_date)
SELECT 'Semester ' || s, s, c.id, '2025-01-01', '2025-06-30'
FROM public.courses c
CROSS JOIN generate_series(1, 8) AS s
WHERE c.code = 'BTECH-CSE'
ON CONFLICT (course_id, semester_number) DO NOTHING;

-- Insert subjects for B.Tech CSE Semesters 1-4
INSERT INTO public.subjects (name, code, description, course_id, semester_id, credits, total_marks, passing_marks) VALUES
('Programming in C', 'CS101', 'Introduction to C Programming', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=1 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Data Structures', 'CS201', 'Data Structures and Algorithms', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=2 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Database Management Systems', 'CS301', 'DBMS concepts and SQL', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=3 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Operating Systems', 'CS302', 'OS concepts and design', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=3 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Computer Networks', 'CS401', 'Network protocols and architecture', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=4 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Object Oriented Programming', 'CS202', 'OOP with Java', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=2 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Engineering Mathematics', 'MA101', 'Calculus and Linear Algebra', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=1 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 4, 100, 40),
('Digital Logic Design', 'EC201', 'Digital circuits and logic', (SELECT id FROM public.courses WHERE code='BTECH-CSE'), (SELECT id FROM public.semesters WHERE semester_number=2 AND course_id=(SELECT id FROM public.courses WHERE code='BTECH-CSE')), 3, 100, 40)
ON CONFLICT (code) DO NOTHING;
