/*
# Exam, Question, Test, and Result Schema

## Overview
Creates tables for exams, question bank, options, student answers, results,
marks, attendance, assignments, and notifications.

## New Tables
1. `exams` - Exam definitions (type, schedule, duration, marks, status)
2. `questions` - Question bank (MCQ, descriptive, true/false) with difficulty
3. `options` - Multiple choice options for MCQ questions
4. `exam_questions` - Many-to-many mapping of questions to exams
5. `student_answers` - Student responses to exam/test questions
6. `results` - Exam results with total marks, percentage, grade, rank
7. `marks` - Subject-wise marks for students
8. `attendance` - Student attendance records per subject/date
9. `assignments` - Teacher-created assignments with file attachments
10. `assignment_submissions` - Student submissions for assignments
11. `notifications` - System notifications for users

## Security
- RLS enabled on all tables
- Admins have full CRUD access
- Teachers can manage exams/questions/results for their assigned subjects
- Students can read their own results/answers/attendance and submit tests/assignments
- Notifications are scoped to the recipient

## Notes
1. Exam types: 'mcq_test', 'descriptive', 'mixed'
2. Question types: 'mcq', 'descriptive', 'true_false'
3. Difficulty levels: 'easy', 'medium', 'hard'
4. Results include auto-calculated grade and rank
5. Attendance status: 'present', 'absent', 'late'
*/

-- Exams
create table if not exists public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  subject_id uuid references public.subjects(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  semester_id uuid references public.semesters(id) on delete set null,
  exam_type text not null check (exam_type in ('mcq_test', 'descriptive', 'mixed')) default 'mcq_test',
  total_marks int not null default 100,
  passing_marks int not null default 40,
  duration_minutes int not null default 180,
  start_time timestamptz,
  end_time timestamptz,
  negative_marking numeric(5,2) default 0,
  randomize_questions boolean not null default false,
  auto_submit boolean not null default false,
  auto_evaluate boolean not null default false,
  is_published boolean not null default false,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.exams enable row level security;

drop policy if exists "exams_select_all" on public.exams;
create policy "exams_select_all" on public.exams
  for select to authenticated using (true);

drop policy if exists "exams_insert_admin_teacher" on public.exams;
create policy "exams_insert_admin_teacher" on public.exams
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "exams_update_admin_teacher" on public.exams;
create policy "exams_update_admin_teacher" on public.exams
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "exams_delete_admin_teacher" on public.exams;
create policy "exams_delete_admin_teacher" on public.exams
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Questions (Question Bank)
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  subject_id uuid references public.subjects(id) on delete cascade,
  question_text text not null,
  question_type text not null check (question_type in ('mcq', 'descriptive', 'true_false')) default 'mcq',
  difficulty text not null check (difficulty in ('easy', 'medium', 'hard')) default 'medium',
  marks int not null default 1,
  explanation text,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.questions enable row level security;

drop policy if exists "questions_select_all" on public.questions;
create policy "questions_select_all" on public.questions
  for select to authenticated using (true);

drop policy if exists "questions_insert_admin_teacher" on public.questions;
create policy "questions_insert_admin_teacher" on public.questions
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "questions_update_admin_teacher" on public.questions;
create policy "questions_update_admin_teacher" on public.questions
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "questions_delete_admin_teacher" on public.questions;
create policy "questions_delete_admin_teacher" on public.questions
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Options (for MCQ and True/False questions)
create table if not exists public.options (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  option_text text not null,
  is_correct boolean not null default false,
  option_order int not null default 0,
  created_at timestamptz not null default now()
);

alter table public.options enable row level security;

drop policy if exists "options_select_all" on public.options;
create policy "options_select_all" on public.options
  for select to authenticated using (true);

drop policy if exists "options_insert_admin_teacher" on public.options;
create policy "options_insert_admin_teacher" on public.options
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "options_update_admin_teacher" on public.options;
create policy "options_update_admin_teacher" on public.options
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "options_delete_admin_teacher" on public.options;
create policy "options_delete_admin_teacher" on public.options
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Exam-Question mapping
create table if not exists public.exam_questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  question_order int not null default 0,
  marks int not null default 1,
  unique(exam_id, question_id)
);

alter table public.exam_questions enable row level security;

drop policy if exists "exam_questions_select_all" on public.exam_questions;
create policy "exam_questions_select_all" on public.exam_questions
  for select to authenticated using (true);

drop policy if exists "exam_questions_insert_admin_teacher" on public.exam_questions;
create policy "exam_questions_insert_admin_teacher" on public.exam_questions
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "exam_questions_update_admin_teacher" on public.exam_questions;
create policy "exam_questions_update_admin_teacher" on public.exam_questions
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "exam_questions_delete_admin_teacher" on public.exam_questions;
create policy "exam_questions_delete_admin_teacher" on public.exam_questions
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Student Answers (for online tests)
create table if not exists public.student_answers (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  selected_option_id uuid references public.options(id) on delete set null,
  answer_text text,
  is_correct boolean,
  marks_awarded numeric(6,2) default 0,
  evaluated_at timestamptz,
  submitted_at timestamptz not null default now(),
  unique(exam_id, question_id, student_id)
);

alter table public.student_answers enable row level security;

drop policy if exists "student_answers_select_admin_teacher_self" on public.student_answers;
create policy "student_answers_select_admin_teacher_self" on public.student_answers
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = student_answers.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "student_answers_insert_self" on public.student_answers;
create policy "student_answers_insert_self" on public.student_answers
  for insert to authenticated
  with check (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = student_answers.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "student_answers_update_admin_teacher" on public.student_answers;
create policy "student_answers_update_admin_teacher" on public.student_answers
  for update to authenticated
  using (public.user_role() in ('admin', 'teacher'))
  with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "student_answers_delete_admin_teacher" on public.student_answers;
create policy "student_answers_delete_admin_teacher" on public.student_answers
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Results
create table if not exists public.results (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  total_marks_obtained numeric(6,2) not null default 0,
  total_marks_possible numeric(6,2) not null default 100,
  percentage numeric(5,2) not null default 0,
  grade text,
  rank int,
  is_passed boolean not null default false,
  is_published boolean not null default false,
  evaluated_at timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(exam_id, student_id)
);

alter table public.results enable row level security;

drop policy if exists "results_select_admin_teacher_self" on public.results;
create policy "results_select_admin_teacher_self" on public.results
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = results.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "results_insert_admin_teacher" on public.results;
create policy "results_insert_admin_teacher" on public.results
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "results_update_admin_teacher" on public.results;
create policy "results_update_admin_teacher" on public.results
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "results_delete_admin_teacher" on public.results;
create policy "results_delete_admin_teacher" on public.results
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Marks (subject-wise marks for students)
create table if not exists public.marks (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid not null references public.subjects(id) on delete cascade,
  exam_id uuid references public.exams(id) on delete set null,
  semester_id uuid references public.semesters(id) on delete set null,
  marks_obtained numeric(6,2) not null default 0,
  total_marks numeric(6,2) not null default 100,
  grade text,
  is_published boolean not null default false,
  entered_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(student_id, subject_id, exam_id)
);

alter table public.marks enable row level security;

drop policy if exists "marks_select_admin_teacher_self" on public.marks;
create policy "marks_select_admin_teacher_self" on public.marks
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = marks.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "marks_insert_admin_teacher" on public.marks;
create policy "marks_insert_admin_teacher" on public.marks
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "marks_update_admin_teacher" on public.marks;
create policy "marks_update_admin_teacher" on public.marks
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "marks_delete_admin_teacher" on public.marks;
create policy "marks_delete_admin_teacher" on public.marks
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Attendance
create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  subject_id uuid references public.subjects(id) on delete set null,
  date date not null default current_date,
  status text not null check (status in ('present', 'absent', 'late')) default 'present',
  remarks text,
  marked_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  unique(student_id, subject_id, date)
);

alter table public.attendance enable row level security;

drop policy if exists "attendance_select_admin_teacher_self" on public.attendance;
create policy "attendance_select_admin_teacher_self" on public.attendance
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = attendance.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "attendance_insert_admin_teacher" on public.attendance;
create policy "attendance_insert_admin_teacher" on public.attendance
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "attendance_update_admin_teacher" on public.attendance;
create policy "attendance_update_admin_teacher" on public.attendance
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "attendance_delete_admin_teacher" on public.attendance;
create policy "attendance_delete_admin_teacher" on public.attendance
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Assignments
create table if not exists public.assignments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  subject_id uuid references public.subjects(id) on delete cascade,
  course_id uuid references public.courses(id) on delete set null,
  semester_id uuid references public.semesters(id) on delete set null,
  file_url text,
  file_name text,
  total_marks int default 100,
  due_date timestamptz,
  is_published boolean not null default false,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.assignments enable row level security;

drop policy if exists "assignments_select_all" on public.assignments;
create policy "assignments_select_all" on public.assignments
  for select to authenticated using (true);

drop policy if exists "assignments_insert_admin_teacher" on public.assignments;
create policy "assignments_insert_admin_teacher" on public.assignments
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "assignments_update_admin_teacher" on public.assignments;
create policy "assignments_update_admin_teacher" on public.assignments
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "assignments_delete_admin_teacher" on public.assignments;
create policy "assignments_delete_admin_teacher" on public.assignments
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Assignment Submissions
create table if not exists public.assignment_submissions (
  id uuid primary key default gen_random_uuid(),
  assignment_id uuid not null references public.assignments(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  file_url text,
  file_name text,
  submission_text text,
  marks_obtained numeric(6,2),
  feedback text,
  is_graded boolean not null default false,
  graded_by uuid references public.profiles(id) on delete set null,
  submitted_at timestamptz not null default now(),
  graded_at timestamptz,
  unique(assignment_id, student_id)
);

alter table public.assignment_submissions enable row level security;

drop policy if exists "submissions_select_admin_teacher_self" on public.assignment_submissions;
create policy "submissions_select_admin_teacher_self" on public.assignment_submissions
  for select to authenticated
  using (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = assignment_submissions.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "submissions_insert_self" on public.assignment_submissions;
create policy "submissions_insert_self" on public.assignment_submissions
  for insert to authenticated
  with check (
    public.user_role() in ('admin', 'teacher')
    or exists (
      select 1 from public.students s
      where s.id = assignment_submissions.student_id and s.profile_id = auth.uid()
    )
  );

drop policy if exists "submissions_update_admin_teacher" on public.assignment_submissions;
create policy "submissions_update_admin_teacher" on public.assignment_submissions
  for update to authenticated using (public.user_role() in ('admin', 'teacher')) with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "submissions_delete_admin_teacher" on public.assignment_submissions;
create policy "submissions_delete_admin_teacher" on public.assignment_submissions
  for delete to authenticated using (public.user_role() in ('admin', 'teacher'));

-- Notifications
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  title text not null,
  message text not null,
  type text check (type in ('info', 'success', 'warning', 'error', 'exam', 'result')) default 'info',
  is_read boolean not null default false,
  link text,
  created_at timestamptz not null default now()
);

alter table public.notifications enable row level security;

drop policy if exists "notifications_select_own_or_admin" on public.notifications;
create policy "notifications_select_own_or_admin" on public.notifications
  for select to authenticated
  using (auth.uid() = user_id or public.user_role() = 'admin');

drop policy if exists "notifications_insert_admin_teacher" on public.notifications;
create policy "notifications_insert_admin_teacher" on public.notifications
  for insert to authenticated with check (public.user_role() in ('admin', 'teacher'));

drop policy if exists "notifications_update_own_or_admin" on public.notifications;
create policy "notifications_update_own_or_admin" on public.notifications
  for update to authenticated
  using (auth.uid() = user_id or public.user_role() = 'admin')
  with check (auth.uid() = user_id or public.user_role() = 'admin');

drop policy if exists "notifications_delete_admin" on public.notifications;
create policy "notifications_delete_admin" on public.notifications
  for delete to authenticated using (public.user_role() = 'admin');

-- Indexes
create index if not exists idx_exams_subject_id on public.exams(subject_id);
create index if not exists idx_exams_created_by on public.exams(created_by);
create index if not exists idx_questions_subject_id on public.questions(subject_id);
create index if not exists idx_options_question_id on public.options(question_id);
create index if not exists idx_exam_questions_exam_id on public.exam_questions(exam_id);
create index if not exists idx_student_answers_exam_student on public.student_answers(exam_id, student_id);
create index if not exists idx_results_exam_student on public.results(exam_id, student_id);
create index if not exists idx_results_student_id on public.results(student_id);
create index if not exists idx_marks_student_subject on public.marks(student_id, subject_id);
create index if not exists idx_attendance_student_date on public.attendance(student_id, date);
create index if not exists idx_attendance_subject_date on public.attendance(subject_id, date);
create index if not exists idx_assignments_subject_id on public.assignments(subject_id);
create index if not exists idx_submissions_assignment_student on public.assignment_submissions(assignment_id, student_id);
create index if not exists idx_notifications_user_id on public.notifications(user_id);
create index if not exists idx_notifications_is_read on public.notifications(is_read);
